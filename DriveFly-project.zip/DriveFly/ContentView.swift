import SwiftUI

@MainActor
struct ContentView: View {
    @EnvironmentObject private var model: ControllerModel
    @State private var showingSettings = false

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 14) {
                Text("DriveFly").font(.title2.bold())
                Picker("控制模式", selection: Binding(get: { model.mode }, set: model.setMode)) {
                    Text("赛车").tag(ControlMode.racing)
                    Text("飞机").tag(ControlMode.flight)
                }
                .pickerStyle(.segmented)
                .frame(maxWidth: 220)
                Spacer(minLength: 0)
                Circle().fill(model.connected ? Color.green : Color.orange).frame(width: 8, height: 8)
                    .accessibilityHidden(true)
                Text(model.connected ? "已连接" : model.status)
                    .font(.caption)
                    .lineLimit(2)
                Button {
                    model.setSettingsOpen(true)
                    showingSettings = true
                } label: {
                    Image(systemName: "gearshape").font(.title3)
                }
                .accessibilityLabel("连接与设置")
            }

            controller
                .id(model.resetEpoch)
                .disabled(!model.controlsEnabled)
                .opacity(model.controlsEnabled ? 1 : 0.6)

            HStack {
                Text(model.motionAvailable ? "横握手机，保持自然姿势后校准" : "等待运动传感器，请允许权限并保持前台")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Button("校准回中", action: model.calibrate)
                    .buttonStyle(.bordered)
                    .disabled(!model.controlsEnabled || !model.motionAvailable)
            }
        }
        .padding(12)
        .background(Color(uiColor: .systemGroupedBackground))
        .sheet(isPresented: $showingSettings, onDismiss: { model.setSettingsOpen(false) }) {
            ConnectionSettings(model: model) { showingSettings = false }
        }
    }

    private var controller: some View {
        VStack(spacing: 10) {
            if model.mode == .racing {
                HStack(spacing: 14) {
                    VStack(spacing: 8) {
                        ZStack {
                            Circle().stroke(Color.accentColor, lineWidth: 4)
                            Capsule().fill(Color.accentColor).frame(width: 4, height: 60)
                                .rotationEffect(.degrees(Double(model.input.steering) * model.steerFullScale))
                        }
                        .frame(width: 68, height: 68)
                        .accessibilityHidden(true)
                        Text("转向 \(Int(Double(model.input.steering) * model.steerFullScale))°")
                            .monospacedDigit()
                        AxisIndicator(label: "转向", value: model.input.steering)
                    }
                    .frame(maxWidth: .infinity)
                    SpringPedal(label: "油门", value: model.input.throttle, color: .green, action: model.setThrottle)
                    SpringPedal(label: "刹车", value: model.input.brake, color: .red, action: model.setBrake)
                    SpringPedal(label: "离合", value: model.input.clutch, color: .blue, action: model.setClutch)
                }
            } else {
                FlightControls(model: model)
            }

            HStack(spacing: 8) {
                ForEach(1...8, id: \.self) { index in
                    HoldButton(label: "\(index)", accessibilityLabel: "按键 \(index)") {
                        model.setButton(index, pressed: $0)
                    }
                }
            }
            .frame(height: 36)
        }
        .frame(maxHeight: .infinity)
    }
}

@MainActor
private struct FlightControls: View {
    @ObservedObject var model: ControllerModel
    @State private var leftHeld = false
    @State private var rightHeld = false

    var body: some View {
        HStack(spacing: 20) {
            VStack(spacing: 14) {
                AxisIndicator(label: "横滚", value: model.input.roll)
                AxisIndicator(label: "俯仰", value: model.input.pitch)
                AxisIndicator(label: "方向舵", value: model.input.yaw)
            }
            .frame(maxWidth: .infinity)
            VStack(spacing: 12) {
                persistentSlider("油门", value: model.input.throttle, action: model.setThrottle)
                persistentSlider("襟翼", value: model.input.flaps, action: model.setFlaps)
            }
            .frame(maxWidth: .infinity)
            VStack(spacing: 8) {
                Text("方向舵").font(.caption).foregroundStyle(.secondary)
                HStack(spacing: 8) {
                    HoldButton(label: "左舵", accessibilityLabel: "左方向舵") {
                        leftHeld = $0
                        updateRudder()
                    }
                    HoldButton(label: "右舵", accessibilityLabel: "右方向舵") {
                        rightHeld = $0
                        updateRudder()
                    }
                }
                .frame(height: 64)
                Text("松开回中").font(.caption).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)
        }
    }

    private func persistentSlider(_ label: String, value: Float, action: @escaping (Float) -> Void) -> some View {
        VStack(spacing: 2) {
            HStack {
                Text(label)
                Spacer()
                Text("\(Int(value * 100))%").monospacedDigit()
            }
            Slider(value: Binding(get: { Double(value) }, set: { action(Float($0)) }), in: 0...1)
                .accessibilityLabel(label)
                .accessibilityValue("\(Int(value * 100))%")
        }
    }

    private func updateRudder() {
        model.setRudder((rightHeld ? 1 : 0) - (leftHeld ? 1 : 0))
    }
}

private struct AxisIndicator: View {
    let label: String
    let value: Float

    var body: some View {
        VStack(spacing: 4) {
            HStack {
                Text(label)
                Spacer()
                Text("\(Int(value * 100))%").monospacedDigit()
            }
            .font(.caption)
            GeometryReader { geometry in
                ZStack {
                    Capsule().fill(Color.secondary.opacity(0.15)).frame(height: 8)
                    Rectangle().fill(Color.secondary).frame(width: 1, height: 14)
                    Circle().fill(Color.accentColor).frame(width: 12, height: 12)
                        .offset(x: CGFloat(value) * max(0, geometry.size.width - 12) / 2)
                }
            }
            .frame(height: 14)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(label)
        .accessibilityValue("\(Int(value * 100))%")
    }
}

private struct SpringPedal: View {
    let label: String
    let value: Float
    let color: Color
    let action: (Float) -> Void
    @GestureState private var dragging = false

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .bottom) {
                RoundedRectangle(cornerRadius: 16).fill(color.opacity(0.12))
                RoundedRectangle(cornerRadius: 16).fill(color.opacity(0.6))
                    .frame(height: geometry.size.height * CGFloat(value))
                VStack(spacing: 4) {
                    Text(label).font(.headline)
                    Text("\(Int(value * 100))%").monospacedDigit()
                    Text("松开归零").font(.caption)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .contentShape(RoundedRectangle(cornerRadius: 16))
            .gesture(DragGesture(minimumDistance: 0)
                .updating($dragging) { _, state, _ in state = true }
                .onChanged { gesture in
                    action(Float(min(1, max(0, 1 - gesture.location.y / max(1, geometry.size.height)))))
                }
                .onEnded { _ in action(0) })
        }
        .frame(maxWidth: .infinity)
        .onChange(of: dragging) { if !$0 { action(0) } }
        .onDisappear { action(0) }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(label)
        .accessibilityValue("\(Int(value * 100))%")
        .accessibilityHint("上下轻扫调整，使用松开操作归零")
        .accessibilityAdjustableAction { direction in
            switch direction {
            case .increment: action(min(1, value + 0.1))
            case .decrement: action(max(0, value - 0.1))
            @unknown default: break
            }
        }
        .accessibilityAction(named: Text("松开")) { action(0) }
    }
}

private struct HoldButton: View {
    let label: String
    let accessibilityLabel: String
    let action: (Bool) -> Void
    @GestureState private var touching = false
    @State private var accessibilityHeld = false

    var body: some View {
        Text(label)
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background((touching || accessibilityHeld) ? Color.accentColor : Color.secondary.opacity(0.14))
            .foregroundStyle((touching || accessibilityHeld) ? Color.white : Color.primary)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .contentShape(RoundedRectangle(cornerRadius: 10))
            .gesture(DragGesture(minimumDistance: 0).updating($touching) { _, state, _ in state = true })
            .onChange(of: touching) { action($0 || accessibilityHeld) }
            .onDisappear {
                accessibilityHeld = false
                action(false)
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(accessibilityLabel)
            .accessibilityValue((touching || accessibilityHeld) ? "按住" : "松开")
            .accessibilityHint("双击按住，再次双击松开")
            .accessibilityAddTraits(.isButton)
            .accessibilityAction {
                accessibilityHeld.toggle()
                action(accessibilityHeld || touching)
            }
    }
}

@MainActor
private struct ConnectionSettings: View {
    @ObservedObject var model: ControllerModel
    let close: () -> Void

    var body: some View {
        NavigationStack {
            Form {
                Section("Windows 接收端") {
                    TextField("电脑的局域网 IPv4，例如 192.168.1.10", text: $model.host)
                        .keyboardType(.decimalPad)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .accessibilityLabel("电脑 IPv4 地址")
                    Text("手机和电脑连接同一个局域网，电脑端监听 UDP 7001。首次连接请允许访问本地网络。")
                        .font(.caption)
                    Text(model.status).font(.caption).foregroundStyle(.secondary)
                    HStack {
                        Button("连接并返回") {
                            if model.connect() { close() }
                        }
                        Spacer()
                        Button("断开连接", role: .destructive, action: model.disconnect)
                    }
                }
                Section("转向设置") {
                    HStack {
                        Text("赛车转向满量程")
                        Spacer()
                        Text("±\(Int(model.steerFullScale))°").monospacedDigit()
                    }
                    Slider(value: $model.steerFullScale, in: 30...120, step: 5)
                        .accessibilityLabel("赛车转向满量程")
                        .accessibilityValue("正负 \(Int(model.steerFullScale)) 度")
                    Text("飞行横滚、俯仰满量程为 ±30°。进入控制界面后，横握手机并点击校准回中。切换模式、打开设置或切到后台都会清空输入。")
                        .font(.caption)
                }
            }
            .navigationTitle("连接与设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("完成", action: close) }
            }
        }
    }
}
