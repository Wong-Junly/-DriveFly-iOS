import SwiftUI

@MainActor
struct ContentView: View {
    @EnvironmentObject private var model: ControllerModel
    @State private var showingSettings = false
    private var appVersion: String {
        let value = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")
        return (value as? String) ?? ""
    }

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 14) {
                Text("DriveFly \(appVersion)")
                    .font(.title2.bold())
                Spacer(minLength: 0)
                Circle().fill(model.connected ? Color.green : Color.orange).frame(width: 8, height: 8)
                    .accessibilityHidden(true)
                Text(model.connected ? "已连接" : model.status)
                    .font(.caption)
                    .lineLimit(2)
                Button {
                    model.setSettingsOpen(true)
                    showingSettings = true
                } label: {
                    Image(systemName: "gearshape").font(.title3)
                }
                .accessibilityLabel("连接与设置")
            }

            HStack(spacing: 12) {
                modeButton("地面载具", mode: .racing, identifier: "mode-ground")
                modeButton("飞机", mode: .flight, identifier: "mode-flight")
            }

            controller
                .id(model.resetEpoch)
                .disabled(!model.controlsEnabled)
                .opacity(model.controlsEnabled ? 1 : 0.6)

            HStack {
                Text(model.motionSuspended ? "手机接近水平，已暂停体感；抬起恢复" :
                        (model.motionAvailable ? (model.mode == .racing ? "横握朝向自己，像方向盘左右旋转" : "横握手机，保持自然姿势后校准") : "等待运动传感器，请允许权限并保持前台"))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Button("校准回中", action: model.calibrate)
                    .buttonStyle(.bordered)
                    .disabled(!model.controlsEnabled || !model.motionAvailable)
            }
        }
        .padding(12)
        .background(Color(uiColor: .systemGroupedBackground))
        .sheet(isPresented: $showingSettings, onDismiss: { model.setSettingsOpen(false) }) {
            ConnectionSettings(model: model) { showingSettings = false }
        }
    }

    private func modeButton(_ title: String, mode: ControlMode, identifier: String) -> some View {
        Button { model.setMode(mode) } label: {
            HStack {
                Text(title)
                if model.mode == mode { Image(systemName: "checkmark") }
            }
            .frame(maxWidth: .infinity, minHeight: 44)
            .contentShape(Rectangle())
        }
        .buttonStyle(.borderedProminent)
        .tint(model.mode == mode ? Color.accentColor : Color.gray)
        .accessibilityIdentifier(identifier)
        .accessibilityValue(model.mode == mode ? "已选中" : "未选中")
    }

    private var controller: some View {
        VStack(spacing: 10) {
            if model.mode == .racing {
                groundControls
            } else {
                FlightControls(model: model)
            }
        }
        .frame(maxHeight: .infinity)
    }

    private var groundControls: some View {
        HStack(spacing: 12) {
            HoldButton(label: "手刹", accessibilityLabel: "手刹，按住生效，松开释放") {
                model.setButton(4, pressed: $0)
            }
            VStack(spacing: 8) {
                HoldButton(label: "解锁载具", accessibilityLabel: "解锁载具") {
                    model.setButton(1, pressed: $0)
                }
                HoldButton(label: "部署补给箱", accessibilityLabel: "部署补给箱") {
                    model.setButton(3, pressed: $0)
                }
                .frame(height: 52)
                HoldButton(label: "对抗装置", accessibilityLabel: "对抗装置") {
                    model.setButton(2, pressed: $0)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            SpringPedal(value: model.input.throttle - model.input.brake, action: model.setDrive)
        }
    }
}

@MainActor
private struct FlightControls: View {
    @ObservedObject var model: ControllerModel
    @State private var collectiveUpHeld = false
    @State private var collectiveDownHeld = false

    var body: some View {
        VStack(spacing: 8) {
            HStack(spacing: 12) {
                VStack(spacing: 8) {
                    HoldButton(label: "总距升高", accessibilityLabel: "总距升高") {
                        collectiveUpHeld = $0
                        updateCollective()
                    }
                    HoldButton(label: "总距降低", accessibilityLabel: "总距降低") {
                        collectiveDownHeld = $0
                        updateCollective()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                VStack(spacing: 8) {
                    HoldButton(label: "解锁载具", accessibilityLabel: "解锁载具") {
                        model.setButton(1, pressed: $0)
                    }
                    HoldButton(label: "部署补给箱", accessibilityLabel: "部署补给箱") {
                        model.setButton(3, pressed: $0)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                VStack(spacing: 8) {
                    HoldButton(label: "攻击", accessibilityLabel: "攻击") {
                        model.setButton(4, pressed: $0)
                    }
                    HoldButton(label: "对抗装置", accessibilityLabel: "对抗装置") {
                        model.setButton(2, pressed: $0)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            HStack(spacing: 12) {
                HoldButton(label: "机头左转", accessibilityLabel: "机头左转") {
                    model.setButton(5, pressed: $0)
                }
                HoldButton(label: "机头右转", accessibilityLabel: "机头右转") {
                    model.setButton(6, pressed: $0)
                }
            }
            .frame(height: 44)
        }
        .onDisappear {
            collectiveUpHeld = false
            collectiveDownHeld = false
            updateCollective()
        }
    }

    private func updateCollective() {
        model.setCollective(up: collectiveUpHeld, down: collectiveDownHeld)
    }
}

private struct SpringPedal: View {
    private let label = "油门，前推前进，后拉倒车"
    let value: Float
    let action: (Float) -> Void
    @GestureState private var dragging = false

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                RoundedRectangle(cornerRadius: 16).fill(Color.green.opacity(0.12))
                Rectangle().fill(Color.secondary.opacity(0.3)).frame(height: 1)
                Capsule().fill(value < 0 ? Color.orange : Color.green)
                    .frame(height: 8).padding(.horizontal, 10)
                    .offset(y: -CGFloat(value) * max(0, geometry.size.height / 2 - 10))
                VStack {
                    Text("↑ 前进").font(.headline)
                    Spacer()
                    Text("\(Int(abs(value) * 100))% · 松开归零").font(.caption)
                    Text("↓ 倒车").font(.headline)
                }.padding(12)
            }
            .contentShape(RoundedRectangle(cornerRadius: 16))
            .gesture(DragGesture(minimumDistance: 0)
                .updating($dragging) { _, state, _ in state = true }
                .onChanged { gesture in
                    action(groundThrottle(position: Double(gesture.location.y), height: Double(geometry.size.height)))
                }
                .onEnded { _ in action(0) })
        }
        .frame(maxWidth: .infinity)
        .onChange(of: dragging) { if !$0 { action(0) } }
        .onDisappear { action(0) }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(label)
        .accessibilityValue("\(Int(value * 100))%")
        .accessibilityHint("上下轻扫调整，使用松开操作归零")
        .accessibilityAdjustableAction { direction in
            switch direction {
            case .increment: action(min(1, value + 0.1))
            case .decrement: action(max(-1, value - 0.1))
            @unknown default: break
            }
        }
        .accessibilityAction(named: Text("松开")) { action(0) }
    }
}

private struct HoldButton: View {
    let label: String
    let accessibilityLabel: String
    let action: (Bool) -> Void
    @GestureState private var touching = false
    @State private var accessibilityHeld = false

    var body: some View {
        Text(label)
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background((touching || accessibilityHeld) ? Color.accentColor : Color.secondary.opacity(0.14))
            .foregroundStyle((touching || accessibilityHeld) ? Color.white : Color.primary)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .contentShape(RoundedRectangle(cornerRadius: 10))
            .gesture(DragGesture(minimumDistance: 0).updating($touching) { _, state, _ in state = true })
            .onChange(of: touching) { action($0 || accessibilityHeld) }
            .onDisappear {
                accessibilityHeld = false
                action(false)
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(accessibilityLabel)
            .accessibilityValue((touching || accessibilityHeld) ? "按住" : "松开")
            .accessibilityHint("双击按住，再次双击松开")
            .accessibilityAddTraits(.isButton)
            .accessibilityAction {
                accessibilityHeld.toggle()
                action(accessibilityHeld || touching)
            }
    }
}

@MainActor
private struct ConnectionSettings: View {
    @ObservedObject var model: ControllerModel
    let close: () -> Void

    var body: some View {
        NavigationStack {
            Form {
                Section("Windows 接收端") {
                    Picker("连接方式", selection: Binding(get: { model.connectionMethod }, set: model.setConnectionMethod)) {
                        ForEach(ConnectionMethod.allCases, id: \.self) { method in
                            Text(method.label).tag(method)
                        }
                    }
                    .pickerStyle(.segmented)
                    TextField("电脑在当前网络的 IPv4", text: $model.host)
                        .keyboardType(.decimalPad)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .accessibilityLabel("电脑 IPv4 地址")
                    Text(connectionInstructions)
                        .font(.caption)
                    Text("三种方式分别保存电脑 IP。请先完成系统网络连接，再填写相应地址；首次连接允许本地网络访问。")
                        .font(.caption)
                    Text(model.status).font(.caption).foregroundStyle(.secondary)
                    HStack {
                        Button("连接并返回") {
                            if model.connect() { close() }
                        }
                        Spacer()
                        Button("断开连接", role: .destructive, action: model.disconnect)
                    }
                }
                Section("地面载具操作") {
                    Text("左侧按住手刹（空格）；右侧油门上推前进、下拉倒车，松手归零。")
                    Text("横握手机、屏幕朝向自己，像方向盘一样左右旋转。保持中立姿势后校准回中。")
                }
                Section("飞行陀螺仪") {
                    Toggle("X 轴反转（左右倾斜）", isOn: $model.flightInvertX)
                    Toggle("Y 轴反转（前倾后仰）", isOn: $model.flightInvertY)
                    HStack {
                        Text("X 轴映射比例")
                        Spacer()
                        Text("\(Int((model.flightScaleX * 100).rounded()))%").monospacedDigit()
                    }
                    Slider(value: Binding(get: { model.flightScaleX }, set: model.setFlightScaleX), in: 0.25...2, step: 0.05)
                        .accessibilityLabel("X 轴映射比例")
                        .accessibilityValue("百分之 \(Int((model.flightScaleX * 100).rounded()))")
                    HStack {
                        Text("Y 轴映射比例")
                        Spacer()
                        Text("\(Int((model.flightScaleY * 100).rounded()))%").monospacedDigit()
                    }
                    Slider(value: Binding(get: { model.flightScaleY }, set: model.setFlightScaleY), in: 0.25...2, step: 0.05)
                        .accessibilityLabel("Y 轴映射比例")
                        .accessibilityValue("百分之 \(Int((model.flightScaleY * 100).rounded()))")
                    Text("X 为左右倾斜，Y 为前倾后仰。默认 100%，比例越大越灵敏；反转和比例分别保存，地面载具转向不受影响。")
                        .font(.caption)
                }
                Section("转向设置") {
                    Toggle("地面转向反转", isOn: $model.steerInvertX)
                    Text("默认关闭：像方向盘向右旋转即右转，向左旋转即左转。此选项单独保存。")
                        .font(.caption)
                    HStack {
                        Text("地面载具转向满量程")
                        Spacer()
                        Text("±\(Int(model.steerFullScale))°").monospacedDigit()
                    }
                    Slider(value: Binding(get: { model.steerFullScale }, set: model.setSteerFullScale), in: 30...120, step: 5)
                        .accessibilityLabel("地面载具转向满量程")
                        .accessibilityValue("正负 \(Int(model.steerFullScale)) 度")
                    Text("飞行在 100% 比例时，横滚、俯仰满量程为 ±30°。进入控制界面后，横握手机并点击校准回中。切换模式、打开设置或切到后台都会清空输入。")
                        .font(.caption)
                }
            }
            .navigationTitle("连接与设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("完成", action: close) }
            }
        }
    }

    private var connectionInstructions: String {
        switch model.connectionMethod {
        case .wifi:
            return "手机和电脑连接同一个 Wi-Fi 或局域网。"
        case .usb:
            return "先开启 iPhone 个人热点，用 USB 连接并信任电脑。Windows 需安装 Apple 设备或 iTunes，个人热点需蜂窝数据与运营商支持。"
        case .bluetooth:
            return "先开启 iPhone 个人热点并与 Windows 蓝牙配对，再让 Windows 加入个人局域网（PAN）。仅配对不够；个人热点需蜂窝数据与运营商支持。"
        }
    }
}
