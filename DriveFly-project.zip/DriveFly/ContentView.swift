import SwiftUI

private let driveFlyAccent = Color(red: 0.04, green: 0.48, blue: 0.42)

@MainActor
struct ContentView: View {
    @EnvironmentObject private var model: ControllerModel
    @State private var showingSettings = false

    var body: some View {
        GeometryReader { geometry in
            let compact = geometry.size.height < 340
            VStack(spacing: compact ? 5 : 10) {
                HStack {
                    Text("DriveFly").font(.headline)
                    Text(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "")
                        .font(.caption2).foregroundStyle(.secondary)
                    Spacer()
                    HStack(spacing: 4) {
                        modeButton("地面", symbol: "car.fill", mode: .racing)
                        modeButton("飞行", symbol: "airplane", mode: .flight)
                    }.padding(3).background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                    Spacer()
                    Button {
                        model.setSettingsOpen(true)
                        showingSettings = true
                    } label: { Label("设置", systemImage: "slider.horizontal.3") }
                    .accessibilityLabel("设置")
                }
                HStack {
                    Circle().fill(model.connected ? driveFlyAccent : Color.secondary).frame(width: 6, height: 6)
                    Text(model.connected ? "已连接 · \(model.connectionMethod.label)" : model.status).lineLimit(1)
                    Spacer(minLength: 4)
                    Text(model.motionAvailable ? "体感控制" : "等待传感器")
                }.font(.caption2).foregroundStyle(.secondary)
                controls(compact: compact, railWidth: min(160, max(108, geometry.size.width * 0.22)))
                    .id(model.resetEpoch).disabled(!model.controlsEnabled).opacity(model.controlsEnabled ? 1 : 0.6)
                Text(inputFeedback).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
            }
            .padding(.horizontal, 14).padding(.vertical, compact ? 6 : 12)
            .background(Color(uiColor: .systemGroupedBackground))
            .tint(driveFlyAccent)
        }
        .sheet(isPresented: $showingSettings, onDismiss: { model.setSettingsOpen(false) }) {
            ConnectionSettings(model: model) { showingSettings = false }
        }
    }

    private func modeButton(_ title: String, symbol: String, mode: ControlMode) -> some View {
        Button { model.setMode(mode) } label: {
            Label(title, systemImage: symbol).font(.subheadline).frame(minWidth: 66, minHeight: 36)
                .background(model.mode == mode ? Color(uiColor: .secondarySystemGroupedBackground) : .clear,
                            in: RoundedRectangle(cornerRadius: 11))
        }.buttonStyle(.plain)
        .accessibilityIdentifier(mode == .racing ? "mode-ground" : "mode-flight")
        .accessibilityValue(model.mode == mode ? "已选中" : "未选中")
    }

    private func controls(compact: Bool, railWidth: CGFloat) -> some View {
        VStack(spacing: 8) {
            HStack(spacing: 14) {
                VStack(spacing: 6) {
                    Text(model.mode == .racing ? "左手" : "左手 · 总距").font(.caption2).foregroundStyle(.secondary)
                    if model.mode == .racing {
                        hold("手刹", symbol: "parkingsign.circle", detail: "按住生效 · SPACE", number: 4, prominent: true)
                    } else {
                        hold("总距升高", symbol: "chevron.up", detail: "按住升高 · W", number: 7, prominent: true)
                        hold("总距降低", symbol: "chevron.down", detail: "按住降低 · S", number: 8, prominent: true)
                    }
                }.frame(width: railWidth)
                VStack(spacing: compact ? 4 : 8) {
                    instrument(compact: compact).frame(maxWidth: .infinity, maxHeight: .infinity)
                    Button(action: model.calibrate) { Label("校准回中", systemImage: "viewfinder") }
                        .font(.caption).buttonStyle(.bordered).frame(minHeight: 36)
                        .disabled(!model.controlsEnabled || !model.motionAvailable)
                    HStack(spacing: 6) {
                        hold("解锁", symbol: "lock.open", number: 1)
                        hold("补给", symbol: "shippingbox", number: 3)
                        if model.mode == .racing { hold("对抗", symbol: "shield", number: 2) }
                    }.frame(height: 44)
                }
                VStack(spacing: 6) {
                    Text(model.mode == .racing ? "右手 · 油门" : "右手").font(.caption2).foregroundStyle(.secondary)
                    if model.mode == .racing {
                        SpringPedal(value: model.input.throttle - model.input.brake, action: model.setDrive)
                    } else {
                        hold("攻击", symbol: "scope", detail: compact ? "" : "按住持续", number: 4)
                        hold("对抗装置", symbol: "shield", number: 2)
                    }
                }.frame(width: railWidth)
            }.frame(maxHeight: .infinity)
            if model.mode == .flight {
                HStack(spacing: 14) {
                    hold("机头左转", symbol: "arrow.turn.up.left", number: 5)
                    Text("方向舵").font(.caption2).foregroundStyle(.secondary)
                    hold("机头右转", symbol: "arrow.turn.up.right", number: 6)
                }.frame(height: 44)
            }
        }
    }

    private func instrument(compact: Bool) -> some View {
        VStack(spacing: 3) {
            Text(model.mode == .racing ? "体感转向" : "飞行体感输入").font(.caption2).foregroundStyle(.secondary)
            GeometryReader { geometry in
                let side = max(24, min(88, min(geometry.size.width, geometry.size.height)))
                Group {
                    if model.mode == .racing {
                        SteeringWheel().stroke(.primary, style: StrokeStyle(lineWidth: side / 16, lineCap: .round))
                            .padding(side / 20).rotationEffect(.degrees(Double(model.input.steering) * 90))
                    } else {
                        Image(systemName: "airplane").resizable().scaledToFit().padding(5)
                            .rotationEffect(.degrees(-90 + Double(model.input.roll) * 30))
                    }
                }.frame(width: side, height: side).frame(maxWidth: .infinity, maxHeight: .infinity).accessibilityHidden(true)
            }
            if model.mode == .racing {
                Text("转向输入 \(Int(model.input.steering * 100))%").font(.caption).monospacedDigit()
            } else {
                Text("横滚 \(Int(model.input.roll * 100))% · 俯仰 \(Int(model.input.pitch * 100))%")
                    .font(.caption).monospacedDigit().minimumScaleFactor(0.8).lineLimit(1)
            }
            if !compact {
                Text(model.mode == .racing ? "像方向盘一样左右转动手机" : "左右同向倾斜 · 前倾低头，后倾抬头")
                    .font(.caption2).foregroundStyle(.secondary).multilineTextAlignment(.center)
            }
        }
    }

    private func hold(_ title: String, symbol: String, detail: String = "", number: Int, prominent: Bool = false) -> some View {
        let name = number == 1 ? "解锁载具" : number == 2 ? "对抗装置" : number == 3 ? "部署补给箱" : title
        return HoldButton(label: title, symbol: symbol, detail: detail,
                          accessibilityLabel: name + "，按住生效，松开释放", prominent: prominent) {
            model.setButton(number, pressed: $0)
        }
    }

    private var inputFeedback: String {
        if model.mode == .flight {
            if model.input.buttons & 192 == 192 { return "总距双键抵消" }
            if model.input.buttons & 64 != 0 { return "总距升高 · W 输入" }
            if model.input.buttons & 128 != 0 { return "总距降低 · S 输入" }
        } else {
            if model.input.buttons & 8 != 0 { return "手刹 · SPACE 输入" }
            if model.input.throttle > 0 { return "前进输入 \(Int(model.input.throttle * 100))%" }
            if model.input.brake > 0 { return "倒车输入 \(Int(model.input.brake * 100))%" }
        }
        return model.input.buttons == 0 ? "触控输入已释放" : "按钮按住中"
    }
}

private struct SteeringWheel: Shape {
    func path(in rect: CGRect) -> Path {
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2
        var path = Path(ellipseIn: CGRect(x: center.x - radius, y: center.y - radius, width: radius * 2, height: radius * 2))
        path.move(to: CGPoint(x: center.x - radius, y: center.y))
        path.addLine(to: CGPoint(x: center.x + radius, y: center.y))
        path.move(to: center)
        path.addLine(to: CGPoint(x: center.x, y: center.y + radius))
        return path
    }
}

private struct SpringPedal: View {
    let value: Float
    let action: (Float) -> Void
    @GestureState private var dragging = false
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                RoundedRectangle(cornerRadius: 22).fill(Color(uiColor: .secondarySystemGroupedBackground))
                Capsule().fill(Color.secondary.opacity(0.15)).frame(width: 4).padding(.vertical, 18)
                Rectangle().fill(Color.secondary.opacity(0.2)).frame(height: 1).padding(.horizontal, 12)
                VStack {
                    Label("前进", systemImage: "chevron.up").font(.caption)
                    Spacer()
                    Label("倒车", systemImage: "chevron.down").font(.caption)
                }.padding(.vertical, 12).foregroundStyle(.secondary)
                VStack(spacing: 4) {
                    Capsule().fill(Color.secondary.opacity(0.3)).frame(width: 24, height: 2)
                    Text("\(Int(abs(value) * 100))%").font(.caption).monospacedDigit()
                    Capsule().fill(Color.secondary.opacity(0.3)).frame(width: 24, height: 2)
                }.frame(maxWidth: .infinity).frame(height: 46)
                .background(Color(uiColor: .tertiarySystemFill), in: RoundedRectangle(cornerRadius: 13))
                .padding(.horizontal, 8).offset(y: -CGFloat(value) * max(0, geometry.size.height / 2 - 32))
            }.contentShape(RoundedRectangle(cornerRadius: 22))
            .gesture(DragGesture(minimumDistance: 0).updating($dragging) { _, state, _ in state = true }
                .onChanged { action(groundThrottle(position: Double($0.location.y), height: Double(geometry.size.height))) }
                .onEnded { _ in action(0) })
        }
        .onChange(of: dragging) { if !$0 { action(0) } }.onDisappear { action(0) }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("油门，前推前进，后拉倒车").accessibilityValue("\(Int(value * 100))%")
        .accessibilityHint("松手回中；辅助功能上下轻扫调整，使用松开操作归零")
        .accessibilityAdjustableAction { direction in
            switch direction {
            case .increment: action(min(1, value + 0.1))
            case .decrement: action(max(-1, value - 0.1))
            @unknown default: break
            }
        }.accessibilityAction(named: Text("松开")) { action(0) }
    }
}

private struct HoldButton: View {
    let label: String
    let symbol: String
    let detail: String
    let accessibilityLabel: String
    let prominent: Bool
    let action: (Bool) -> Void
    @GestureState private var touching = false
    @State private var accessibilityHeld = false
    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: symbol).font(.body)
            Text(label).font(.subheadline.weight(.medium))
            if !detail.isEmpty { Text(detail).font(.caption2) }
        }.multilineTextAlignment(.center).frame(maxWidth: .infinity, maxHeight: .infinity)
        .background((touching || accessibilityHeld) ? driveFlyAccent :
                        (prominent ? driveFlyAccent.opacity(0.12) : Color(uiColor: .secondarySystemGroupedBackground)))
        .foregroundStyle((touching || accessibilityHeld) ? Color.white : Color.primary)
        .clipShape(RoundedRectangle(cornerRadius: 18)).contentShape(RoundedRectangle(cornerRadius: 18))
        .gesture(DragGesture(minimumDistance: 0).updating($touching) { _, state, _ in state = true })
        .onChange(of: touching) { action($0 || accessibilityHeld) }
        .onDisappear { accessibilityHeld = false; action(false) }
        .accessibilityElement(children: .ignore).accessibilityLabel(accessibilityLabel)
        .accessibilityValue((touching || accessibilityHeld) ? "按住" : "松开")
        .accessibilityHint("双击按住，再次双击松开").accessibilityAddTraits(.isButton)
        .accessibilityAction { accessibilityHeld.toggle(); action(accessibilityHeld || touching) }
    }
}

@MainActor
private struct ConnectionSettings: View {
    @ObservedObject var model: ControllerModel
    let close: () -> Void
    @State private var selected = Category.connection
    private enum Category: String, CaseIterable {
        case connection = "链接设置"
        case ground = "地面载具操作设置"
        case flight = "飞行载具操作设置"
        case sensitivity = "陀螺仪灵敏度设置"
        var symbol: String {
            switch self {
            case .connection: return "link"
            case .ground: return "car.fill"
            case .flight: return "airplane"
            case .sensitivity: return "slider.horizontal.3"
            }
        }
    }
    var body: some View {
        NavigationStack {
            HStack(spacing: 0) {
                ScrollView {
                    VStack(spacing: 6) {
                        ForEach(Category.allCases, id: \.self) { category in
                            Button { selected = category } label: {
                                Label(category.rawValue, systemImage: category.symbol)
                                    .font(.subheadline).multilineTextAlignment(.leading)
                                    .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading).padding(8)
                                    .background(selected == category ? driveFlyAccent.opacity(0.12) : .clear,
                                                in: RoundedRectangle(cornerRadius: 12))
                            }.buttonStyle(.plain).accessibilityValue(selected == category ? "已选中" : "未选中")
                        }
                    }.padding(10)
                }.frame(width: 185)
                Form { Section(selected.rawValue) { settingsContent } }.id(selected)
            }.background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("设置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("返回操作", action: close) } }
        }
    }
    @ViewBuilder private var settingsContent: some View {
        switch selected {
        case .connection:
            Picker("连接方式", selection: Binding(get: { model.connectionMethod }, set: model.setConnectionMethod)) {
                ForEach(ConnectionMethod.allCases, id: \.self) { Text($0.label).tag($0) }
            }.pickerStyle(.segmented)
            TextField("电脑在当前网络的 IPv4", text: $model.host)
                .keyboardType(.decimalPad).textInputAutocapitalization(.never).autocorrectionDisabled()
                .accessibilityLabel("电脑 IPv4 地址")
            Text(connectionInstructions).font(.caption)
            Text("三种方式分别保存电脑 IP。首次连接请允许本地网络访问。").font(.caption)
            Text(model.status).font(.caption).foregroundStyle(.secondary)
            Button("连接并返回") { if model.connect() { close() } }
            Button("断开连接", role: .destructive, action: model.disconnect)
        case .ground:
            Toggle("地面转向反转", isOn: $model.steerInvertX)
            Text("默认关闭：像方向盘一样向左转手机即左转，向右即右转。")
            LabeledContent("手刹", value: "空格 · 按住生效")
            Text("右侧油门上推前进，下拉倒车，松手回中。")
            Text("进入操作页，以自然横握姿势校准回中。").font(.caption)
        case .flight:
            Toggle("左右倾斜反转", isOn: $model.flightInvertX)
            Toggle("前后倾斜反转", isOn: $model.flightInvertY)
            Text("默认左右同向倾斜，前倾低头、后倾抬头；倾斜幅度决定输入大小。")
            LabeledContent("总距升高 / 降低", value: "W / S")
            Text("按住持续输入，松开停止；两键同时按下时抵消。需配套 Windows 0.5.2 或更新版。").font(.caption)
        case .sensitivity:
            LabeledContent("地面转向满幅角度", value: "±\(Int(model.steerFullScale))°")
            Slider(value: Binding(get: { model.steerFullScale }, set: model.setSteerFullScale), in: 30...120, step: 5)
                .accessibilityLabel("地面转向满幅角度")
            Text("角度越小越灵敏。").font(.caption)
            LabeledContent("飞行左右倾斜", value: "\(Int((model.flightScaleX * 100).rounded()))%")
            Slider(value: Binding(get: { model.flightScaleX }, set: model.setFlightScaleX), in: 0.25...2, step: 0.05)
                .accessibilityLabel("飞行左右倾斜灵敏度")
            LabeledContent("飞行前后倾斜", value: "\(Int((model.flightScaleY * 100).rounded()))%")
            Slider(value: Binding(get: { model.flightScaleY }, set: model.setFlightScaleY), in: 0.25...2, step: 0.05)
                .accessibilityLabel("飞行前后倾斜灵敏度")
            Text("100% 时飞行满幅角度为 ±30°，比例越大越灵敏。").font(.caption)
        }
    }
    private var connectionInstructions: String {
        switch model.connectionMethod {
        case .wifi: return "手机和电脑连接同一个 Wi-Fi 或局域网。"
        case .usb: return "开启 iPhone 个人热点，用 USB 连接并信任电脑。Windows 需安装 Apple 设备或 iTunes；个人热点需蜂窝数据与运营商支持。"
        case .bluetooth: return "开启个人热点并与 Windows 蓝牙配对，再让 Windows 加入个人局域网（PAN）。仅配对不够；个人热点需蜂窝数据与运营商支持。"
        }
    }
}
