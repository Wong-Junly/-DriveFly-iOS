import Foundation

enum ControlMode: String {
    case racing
    case flight
}

enum ConnectionMethod: String, CaseIterable {
    case wifi
    case usb
    case bluetooth

    static let preferenceKey = "connectionMethod"

    var label: String {
        switch self {
        case .wifi: return "Wi-Fi"
        case .usb: return "USB 网络"
        case .bluetooth: return "蓝牙网络"
        }
    }

    var hostKey: String { "host.\(rawValue)" }

    static func restore(_ rawValue: String?) -> ConnectionMethod {
        ConnectionMethod(rawValue: rawValue ?? "") ?? .wifi
    }

    func savedHost(in preferences: UserDefaults) -> String {
        preferences.string(forKey: hostKey) ?? (self == .wifi ? preferences.string(forKey: "host") ?? "" : "")
    }
}

struct ControllerInput {
    var mode: ControlMode = .racing
    var steering: Float = 0
    var throttle: Float = 0
    var brake: Float = 0
    var clutch: Float = 0
    var roll: Float = 0
    var pitch: Float = 0
    var yaw: Float = 0
    var flaps: Float = 0
    var buttons: UInt32 = 0

    mutating func setButton(_ number: Int, pressed: Bool) {
        guard (1...8).contains(number) else { return }
        let mask = UInt32(1) << UInt32(number - 1)
        if pressed { buttons |= mask } else { buttons &= ~mask }
        if mode == .flight && (7...8).contains(number) {
            setCollective(up: buttons & 64 != 0, down: buttons & 128 != 0)
        }
    }

    mutating func setDrive(_ value: Float) {
        guard mode == .racing, value.isFinite else { return }
        throttle = min(1, max(0, value))
        brake = min(1, max(0, -value))
    }

    mutating func setCollective(up: Bool, down: Bool) {
        guard mode == .flight else { return }
        throttle = up && !down ? 1 : 0
        flaps = down && !up ? 1 : 0
        yaw = 0
    }
}

enum InputProtocol {
    static let ack: UInt8 = 0x7e

    enum EncodingError: Error, Equatable {
        case invalidAxis
        case invalidTimestamp
    }

    static func encode(_ input: ControllerInput, timestamp: Int64) throws -> Data {
        guard timestamp >= 0 else { throw EncodingError.invalidTimestamp }
        let axes: [Float]
        let signedCount: Int
        switch input.mode {
        case .racing:
            axes = [input.steering, input.throttle, input.brake, input.clutch]
            signedCount = 1
        case .flight:
            axes = [input.roll, input.pitch, input.yaw, input.throttle, input.flaps]
            signedCount = 3
        }
        for (index, value) in axes.enumerated() {
            let minimum: Float = index < signedCount ? -1 : 0
            guard value.isFinite, value >= minimum, value <= 1 else {
                throw EncodingError.invalidAxis
            }
        }
        var packet = Data([input.mode == .racing ? 1 : 2])
        for value in axes { appendLittleEndian(value.bitPattern, to: &packet) }
        appendLittleEndian(input.buttons, to: &packet)
        appendLittleEndian(UInt64(bitPattern: timestamp), to: &packet)
        return packet
    }

    private static func appendLittleEndian<T: FixedWidthInteger>(_ value: T, to data: inout Data) {
        var littleEndian = value.littleEndian
        withUnsafeBytes(of: &littleEndian) { data.append(contentsOf: $0) }
    }
}

struct MotionAngles {
    let roll: Double
    let pitch: Double
}

struct MotionSampleGate {
    private var lastSample: Double?
    private var lastArrival: UInt64?

    mutating func reset(baseline: Double?) {
        lastSample = baseline.flatMap { $0.isFinite ? $0 : nil }
        lastArrival = nil
    }

    mutating func accept(timestamp: Double, now: UInt64) -> Bool {
        guard timestamp.isFinite, timestamp >= 0 else { return false }
        if let previous = lastSample, timestamp <= previous { return false }
        lastSample = timestamp
        lastArrival = now
        return true
    }

    func isFresh(now: UInt64) -> Bool {
        guard let arrival = lastArrival, now >= arrival else { return false }
        return now - arrival < 500_000_000
    }
}

final class QuaternionMotionCalculator {
    private typealias Quaternion = (x: Double, y: Double, z: Double, w: Double)
    private var current: Quaternion?
    private var home: Quaternion?

    func calibrate() {
        home = current
    }

    func reset() {
        current = nil
        home = nil
    }

    func update(x: Double, y: Double, z: Double, w: Double, landscapeLeft: Bool) -> MotionAngles? {
        guard x.isFinite, y.isFinite, z.isFinite, w.isFinite else { return nil }
        let norm = sqrt(x * x + y * y + z * z + w * w)
        guard norm.isFinite, norm >= 0.001 else { return nil }
        // Core Motion maps reference to device; conjugate to device to reference.
        let q: Quaternion = (-x / norm, -y / norm, -z / norm, w / norm)
        current = q
        if home == nil { home = q }
        guard let h = home else { return nil }

        // inverse(home) * current measures movement in the calibrated device frame.
        let relativeX = h.w * q.x - h.x * q.w - h.y * q.z + h.z * q.y
        let relativeY = h.w * q.y + h.x * q.z - h.y * q.w - h.z * q.x
        let relativeZ = h.w * q.z - h.x * q.y + h.y * q.x - h.z * q.w
        let relativeW = h.w * q.w + h.x * q.x + h.y * q.y + h.z * q.z
        // landscapeLeft follows UIInterfaceOrientation (Home button on the left).
        let screenX = landscapeLeft ? relativeY : -relativeY
        let screenY = landscapeLeft ? -relativeX : relativeX
        let roll = -atan2(2 * (relativeW * relativeZ + screenX * screenY),
                          1 - 2 * (screenY * screenY + relativeZ * relativeZ))
        let pitch = atan2(2 * (relativeW * screenX + screenY * relativeZ),
                          1 - 2 * (screenX * screenX + screenY * screenY))
        return MotionAngles(roll: roll * 180 / .pi, pitch: pitch * 180 / .pi)
    }

    static func normalize(angle: Double, fullScale: Double, deadzone: Double = 2, scale: Double = 1, inverted: Bool = false) -> Float {
        guard angle.isFinite, fullScale.isFinite, deadzone.isFinite, scale.isFinite,
              deadzone >= 0, fullScale > deadzone, scale > 0 else { return 0 }
        guard abs(angle) > deadzone else { return 0 }
        let magnitude = min(1, (abs(angle) - deadzone) / (fullScale - deadzone) * scale)
        return Float(angle < 0 ? -magnitude : magnitude) * (inverted ? -1 : 1)
    }
}

// Gravity anchors upright steering; the gyro carries it through a flat phone pose.
final class SteeringMotionCalculator {
    private var current: Double?
    private var home: Double?
    private var previousTimestamp: Double?
    private var gravityOffset = 0.0
    private var usingGyro = false

    func calibrate() { home = current }
    func reset() {
        current = nil
        home = nil
        previousTimestamp = nil
        gravityOffset = 0
        usingGyro = false
    }

    func update(gravityX: Double, gravityY: Double, gravityZ: Double,
                landscapeLeft: Bool, rotationRateZ: Double = 0, timestamp: Double = 0) -> Double? {
        guard gravityX.isFinite, gravityY.isFinite, gravityZ.isFinite,
              rotationRateZ.isFinite, timestamp.isFinite, timestamp >= 0 else { return nil }
        let length = sqrt(gravityX * gravityX + gravityY * gravityY + gravityZ * gravityZ)
        guard length.isFinite, length >= 0.001 else { return nil }
        let dt = previousTimestamp.map { min(0.1, max(0, timestamp - $0)) } ?? 0
        previousTimestamp = timestamp
        let predicted = (current ?? 0) - rotationRateZ * dt
        if hypot(gravityX, gravityY) / length < 0.05 {
            current = predicted
            usingGyro = true
        } else {
            let angle = landscapeLeft ? atan2(gravityY, gravityX) : atan2(-gravityY, -gravityX)
            // Rejoining gravity must preserve the turn accumulated while flat.
            if usingGyro { gravityOffset = predicted - angle }
            current = angle + gravityOffset
            usingGyro = false
        }
        guard let angle = current else { return nil }
        if home == nil { home = angle }
        let delta = angle - (home ?? angle)
        return atan2(sin(delta), cos(delta)) * 180 / .pi
    }
}

func groundThrottle(position: Double, height: Double) -> Float {
    guard position.isFinite, height.isFinite, height > 0 else { return 0 }
    let raw = min(1, max(-1, 1 - 2 * position / height))
    let magnitude = max(0, (abs(raw) - 0.08) / 0.92)
    return Float(raw < 0 ? -magnitude : magnitude)
}
