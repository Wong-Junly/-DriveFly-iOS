import Combine
import CoreMotion
import Foundation
import Network
import UIKit

@MainActor
final class ControllerModel: ObservableObject {
    @Published private(set) var mode: ControlMode = .racing
    @Published var host: String
    @Published private(set) var connected = false
    @Published private(set) var status = "请在设置中填写电脑 IP"
    @Published private(set) var input = ControllerInput()
    @Published private(set) var motionAvailable = false
    @Published private(set) var resetEpoch = 0
    @Published private(set) var controlsEnabled = false
    @Published var steerFullScale: Double {
        didSet {
            if !steerFullScale.isFinite { steerFullScale = 60 }
            steerFullScale = min(120, max(30, steerFullScale))
            UserDefaults.standard.set(steerFullScale, forKey: "steerFullScale")
        }
    }

    private let motion = CMMotionManager()
    private var calculator = QuaternionMotionCalculator()
    private var motionGate = MotionSampleGate()
    private var connection: NWConnection?
    private var timer: Timer?
    private var active = false
    private var settingsOpen = false
    private var wantsConnection: Bool
    private var ready = false
    private var sending = false
    private var receiving = false
    private var lastAck: UInt64?
    private var retryAfter: UInt64 = 0
    private var previousOrientation: UIInterfaceOrientation?
    private let clockOrigin = DispatchTime.now().uptimeNanoseconds

    init() {
        let savedHost = UserDefaults.standard.string(forKey: "host") ?? ""
        host = savedHost
        wantsConnection = !savedHost.isEmpty
        let savedScale = UserDefaults.standard.double(forKey: "steerFullScale")
        steerFullScale = savedScale.isFinite && savedScale >= 30 && savedScale <= 120 ? savedScale : 60
    }

    func activate() {
        guard UIApplication.shared.applicationState == .active, !settingsOpen, !active else { return }
        active = true
        controlsEnabled = true
        resetInputs()
        motionGate.reset(baseline: motion.deviceMotion?.timestamp)
        if motion.isDeviceMotionAvailable {
            motion.deviceMotionUpdateInterval = 0.01
            motion.startDeviceMotionUpdates(using: .xArbitraryZVertical)
        }
        let newTimer = Timer(timeInterval: 0.014, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
        timer = newTimer
        RunLoop.main.add(newTimer, forMode: .common)
        if wantsConnection { openConnection() }
    }

    func deactivate() {
        active = false
        controlsEnabled = false
        resetInputs()
        // The receiver also releases input after 500 ms if this final UDP packet is lost.
        if ready, let current = connection, let neutral = try? InputProtocol.encode(input, timestamp: timestamp()) {
            current.send(content: neutral, completion: .idempotent)
        }
        closeConnection()
        status = "已暂停"
        timer?.invalidate()
        timer = nil
        motion.stopDeviceMotionUpdates()
    }

    func setSettingsOpen(_ open: Bool) {
        settingsOpen = open
        if open { deactivate() } else { activate() }
    }

    @discardableResult
    func connect() -> Bool {
        guard let canonical = Self.canonicalIPv4(host) else {
            status = "请输入电脑的 IPv4 地址，例如 192.168.1.10"
            return false
        }
        host = canonical
        UserDefaults.standard.set(canonical, forKey: "host")
        wantsConnection = true
        resetInputs()
        closeConnection()
        status = "等待电脑回复"
        if active { openConnection() }
        return true
    }

    func disconnect() {
        wantsConnection = false
        resetInputs()
        if ready, let current = connection, let neutral = try? InputProtocol.encode(input, timestamp: timestamp()) {
            current.send(content: neutral, completion: .idempotent)
        }
        closeConnection()
        status = "已断开"
    }

    func setMode(_ newMode: ControlMode) {
        guard newMode != mode else { return }
        mode = newMode
        resetInputs()
    }

    func calibrate() {
        guard controlsEnabled, motionAvailable else { return }
        calculator.calibrate()
        input.steering = 0
        input.roll = 0
        input.pitch = 0
    }

    func setThrottle(_ value: Float) {
        guard controlsEnabled, value.isFinite else { return }
        input.throttle = min(1, max(0, value))
    }

    func setBrake(_ value: Float) {
        guard controlsEnabled, value.isFinite else { return }
        input.brake = min(1, max(0, value))
    }

    func setClutch(_ value: Float) {
        guard controlsEnabled, value.isFinite else { return }
        input.clutch = min(1, max(0, value))
    }

    func setRudder(_ value: Float) {
        guard controlsEnabled, value.isFinite else { return }
        input.yaw = min(1, max(-1, value))
    }

    func setFlaps(_ value: Float) {
        guard controlsEnabled, value.isFinite else { return }
        input.flaps = min(1, max(0, value))
    }

    func setButton(_ number: Int, pressed: Bool) {
        guard controlsEnabled, (1...8).contains(number) else { return }
        let mask = UInt32(1) << UInt32(number - 1)
        if pressed { input.buttons |= mask } else { input.buttons &= ~mask }
    }

    static func canonicalIPv4(_ text: String) -> String? {
        let fields = text.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: ".", omittingEmptySubsequences: false)
        guard fields.count == 4 else { return nil }
        let octets = fields.compactMap { field -> Int? in
            guard !field.isEmpty, field.allSatisfy({ $0 >= "0" && $0 <= "9" }), let value = Int(field), (0...255).contains(value) else { return nil }
            return value
        }
        guard octets.count == 4, (1...223).contains(octets[0]) else { return nil }
        return octets.map(String.init).joined(separator: ".")
    }

    private func resetInputs() {
        input = ControllerInput()
        input.mode = mode
        calculator.reset()
        motionAvailable = false
        previousOrientation = nil
        resetEpoch += 1
    }

    private func timestamp() -> Int64 {
        Int64((DispatchTime.now().uptimeNanoseconds - clockOrigin) / 1_000_000) + 1
    }

    private func tick() {
        guard active else { return }
        let now = DispatchTime.now().uptimeNanoseconds
        if connected, let ack = lastAck, now - ack >= 500_000_000 {
            connected = false
            status = "未收到回复，正在重连"
            resetInputs()
        }
        if let data = motion.deviceMotion, motionGate.accept(timestamp: data.timestamp, now: now) {
            let orientation = UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .first(where: { $0.activationState == .foregroundActive })?.interfaceOrientation ?? .landscapeRight
            if previousOrientation != nil && previousOrientation != orientation { resetInputs() }
            previousOrientation = orientation
            let q = data.attitude.quaternion
            if let angles = calculator.update(x: q.x, y: q.y, z: q.z, w: q.w, landscapeLeft: orientation == .landscapeLeft) {
                motionAvailable = true
                input.steering = QuaternionMotionCalculator.normalize(angle: angles.roll, fullScale: steerFullScale)
                input.roll = QuaternionMotionCalculator.normalize(angle: angles.roll, fullScale: 30)
                input.pitch = QuaternionMotionCalculator.normalize(angle: angles.pitch, fullScale: 30)
            } else {
                motionAvailable = false
            }
        }
        if !motionGate.isFresh(now: now) || !motionAvailable {
            input.steering = 0
            input.roll = 0
            input.pitch = 0
            calculator.reset()
            motionAvailable = false
        }
        if wantsConnection, connection == nil, now >= retryAfter { openConnection() }
        guard ready, !sending, let current = connection else { return }
        do {
            let packet = try InputProtocol.encode(input, timestamp: timestamp())
            sending = true
            current.send(content: packet, completion: .contentProcessed { [weak self, weak current] error in
                Task { @MainActor in
                    guard let self, let current, self.connection === current else { return }
                    self.sending = false
                    if error != nil { self.connectionFailed(current) }
                }
            })
        } catch {
            resetInputs()
            status = "输入无效，已回中"
        }
    }

    private func openConnection() {
        guard active, wantsConnection, let validHost = Self.canonicalIPv4(host) else { return }
        let current = NWConnection(host: NWEndpoint.Host(validHost), port: 7001, using: .udp)
        connection = current
        status = "等待电脑回复；请允许本地网络访问"
        current.stateUpdateHandler = { [weak self, weak current] state in
            Task { @MainActor in
                guard let self, let current, self.active, self.connection === current else { return }
                switch state {
                case .ready:
                    self.ready = true
                    self.receiveAck(current)
                case .waiting:
                    self.connected = false
                    self.ready = false
                    self.status = "检查 Wi-Fi、本地网络权限和电脑 IP"
                    self.resetInputs()
                case .failed:
                    self.connectionFailed(current)
                default:
                    break
                }
            }
        }
        current.start(queue: .main)
    }

    private func receiveAck(_ current: NWConnection) {
        guard active, ready, connection === current, !receiving else { return }
        receiving = true
        current.receiveMessage { [weak self, weak current] data, _, _, error in
            Task { @MainActor in
                guard let self, let current, self.active, self.connection === current else { return }
                self.receiving = false
                if error != nil {
                    self.connectionFailed(current)
                    return
                }
                if data == Data([InputProtocol.ack]) {
                    self.lastAck = DispatchTime.now().uptimeNanoseconds
                    self.connected = true
                    self.status = "已连接"
                }
                self.receiveAck(current)
            }
        }
    }

    private func connectionFailed(_ current: NWConnection) {
        guard connection === current else { return }
        resetInputs()
        closeConnection()
        retryAfter = DispatchTime.now().uptimeNanoseconds + 600_000_000
        status = "连接中断，正在重试；检查接收端和网络权限"
    }

    private func closeConnection() {
        let previous = connection
        connection = nil
        ready = false
        sending = false
        receiving = false
        connected = false
        lastAck = nil
        previous?.cancel()
    }
}
