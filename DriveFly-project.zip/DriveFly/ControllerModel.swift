import Combine
import CoreMotion
import Foundation
import Network
import UIKit

@MainActor
final class ControllerModel: ObservableObject {
    @Published private(set) var mode: ControlMode = .racing
    @Published private(set) var connectionMethod: ConnectionMethod
    @Published var host: String {
        didSet { UserDefaults.standard.set(host, forKey: connectionMethod.hostKey) }
    }
    @Published private(set) var connected = false
    @Published private(set) var status = "请在设置中填写电脑 IP"
    @Published private(set) var input = ControllerInput()
    @Published private(set) var motionAvailable = false
    @Published private(set) var motionSuspended = false
    @Published private(set) var resetEpoch = 0
    @Published private(set) var controlsEnabled = false
    @Published var throttleOnLeft: Bool {
        didSet { UserDefaults.standard.set(throttleOnLeft, forKey: "throttleOnLeft") }
    }
    @Published var steerInvertX: Bool {
        didSet {
            UserDefaults.standard.set(steerInvertX, forKey: "steerInvertX")
            input.steering = 0
        }
    }
    @Published var flightInvertX: Bool {
        didSet { UserDefaults.standard.set(flightInvertX, forKey: "flightInvertX") }
    }
    @Published var flightInvertY: Bool {
        didSet { UserDefaults.standard.set(flightInvertY, forKey: "flightInvertY") }
    }
    @Published var flightScaleX: Double {
        didSet {
            if !flightScaleX.isFinite { flightScaleX = 1 }
            flightScaleX = min(2, max(0.25, flightScaleX))
            UserDefaults.standard.set(flightScaleX, forKey: "flightScaleX")
        }
    }
    @Published var flightScaleY: Double {
        didSet {
            if !flightScaleY.isFinite { flightScaleY = 1 }
            flightScaleY = min(2, max(0.25, flightScaleY))
            UserDefaults.standard.set(flightScaleY, forKey: "flightScaleY")
        }
    }
    @Published var steerFullScale: Double {
        didSet {
            if !steerFullScale.isFinite { steerFullScale = 60 }
            steerFullScale = min(120, max(30, steerFullScale))
            UserDefaults.standard.set(steerFullScale, forKey: "steerFullScale")
        }
    }

    private let motion = CMMotionManager()
    private var calculator = QuaternionMotionCalculator()
    private var motionGate = MotionSampleGate()
    private var connection: NWConnection?
    private var timer: Timer?
    private var active = false
    private var settingsOpen = false
    private var wantsConnection: Bool
    private var ready = false
    private var sending = false
    private var receiving = false
    private var lastAck: UInt64?
    private var retryAfter: UInt64 = 0
    private var previousOrientation: UIInterfaceOrientation?
    private let clockOrigin = DispatchTime.now().uptimeNanoseconds

    init() {
        let savedMethod = ConnectionMethod.restore(UserDefaults.standard.string(forKey: ConnectionMethod.preferenceKey))
        connectionMethod = savedMethod
        let savedHost = savedMethod.savedHost(in: .standard)
        host = savedHost
        wantsConnection = Self.canonicalIPv4(savedHost) != nil
        throttleOnLeft = UserDefaults.standard.bool(forKey: "throttleOnLeft")
        steerInvertX = (UserDefaults.standard.object(forKey: "steerInvertX") as? Bool) ?? true
        flightInvertX = UserDefaults.standard.bool(forKey: "flightInvertX")
        flightInvertY = UserDefaults.standard.bool(forKey: "flightInvertY")
        let savedFlightScaleX = UserDefaults.standard.double(forKey: "flightScaleX")
        flightScaleX = savedFlightScaleX.isFinite && savedFlightScaleX >= 0.25 && savedFlightScaleX <= 2 ? savedFlightScaleX : 1
        let savedFlightScaleY = UserDefaults.standard.double(forKey: "flightScaleY")
        flightScaleY = savedFlightScaleY.isFinite && savedFlightScaleY >= 0.25 && savedFlightScaleY <= 2 ? savedFlightScaleY : 1
        let savedScale = UserDefaults.standard.double(forKey: "steerFullScale")
        steerFullScale = savedScale.isFinite && savedScale >= 30 && savedScale <= 120 ? savedScale : 60
    }

    func activate() {
        guard UIApplication.shared.applicationState == .active, !settingsOpen, !active else { return }
        active = true
        controlsEnabled = true
        resetInputs()
        motionGate.reset(baseline: motion.deviceMotion?.timestamp)
        if motion.isDeviceMotionAvailable {
            motion.deviceMotionUpdateInterval = 0.01
            motion.startDeviceMotionUpdates(using: .xArbitraryZVertical)
        }
        let newTimer = Timer(timeInterval: 0.014, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
        timer = newTimer
        RunLoop.main.add(newTimer, forMode: .common)
        if wantsConnection { openConnection() }
    }

    func deactivate() {
        active = false
        controlsEnabled = false
        resetInputs()
        // The receiver also releases input after 500 ms if this final UDP packet is lost.
        if ready, let current = connection, let neutral = try? InputProtocol.encode(input, timestamp: timestamp()) {
            current.send(content: neutral, completion: .idempotent)
        }
        closeConnection()
        status = "已暂停"
        timer?.invalidate()
        timer = nil
        motion.stopDeviceMotionUpdates()
    }

    func setSettingsOpen(_ open: Bool) {
        settingsOpen = open
        if open { deactivate() } else { activate() }
    }

    @discardableResult
    func connect() -> Bool {
        guard let canonical = Self.canonicalIPv4(host) else {
            status = "请输入\(connectionMethod.label)中电脑的 IPv4 地址"
            return false
        }
        disconnect()
        host = canonical
        wantsConnection = true
        status = "等待通过\(connectionMethod.label)收到电脑回复"
        if active { openConnection() }
        return true
    }

    func setConnectionMethod(_ newMethod: ConnectionMethod) {
        guard newMethod != connectionMethod else { return }
        disconnect()
        connectionMethod = newMethod
        UserDefaults.standard.set(newMethod.rawValue, forKey: ConnectionMethod.preferenceKey)
        host = newMethod.savedHost(in: .standard)
        guard Self.canonicalIPv4(host) != nil else {
            status = "请先完成\(newMethod.label)的系统连接，再填写电脑 IPv4"
            return
        }
        wantsConnection = true
        status = "等待通过\(newMethod.label)收到电脑回复"
        if active { openConnection() }
    }

    func disconnect() {
        wantsConnection = false
        resetInputs()
        if ready, let current = connection, let neutral = try? InputProtocol.encode(input, timestamp: timestamp()) {
            current.send(content: neutral, completion: .idempotent)
        }
        closeConnection()
        status = "已断开"
    }

    func setMode(_ newMode: ControlMode) {
        guard newMode != mode else { return }
        mode = newMode
        resetInputs()
    }

    func calibrate() {
        guard controlsEnabled, motionAvailable else { return }
        calculator.calibrate()
        input.steering = 0
        input.roll = 0
        input.pitch = 0
    }

    func setThrottle(_ value: Float) {
        guard controlsEnabled, value.isFinite else { return }
        input.throttle = min(1, max(0, value))
    }

    func setBrake(_ value: Float) {
        guard controlsEnabled, value.isFinite else { return }
        input.brake = min(1, max(0, value))
    }

    func setCollective(up: Bool, down: Bool) {
        guard controlsEnabled, mode == .flight else { return }
        var updated = input
        updated.setCollective(up: up, down: down)
        input = updated
    }

    func setButton(_ number: Int, pressed: Bool) {
        guard controlsEnabled, (1...8).contains(number) else { return }
        let mask = UInt32(1) << UInt32(number - 1)
        if pressed { input.buttons |= mask } else { input.buttons &= ~mask }
    }

    static func canonicalIPv4(_ text: String) -> String? {
        let fields = text.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: ".", omittingEmptySubsequences: false)
        guard fields.count == 4 else { return nil }
        let octets = fields.compactMap { field -> Int? in
            guard !field.isEmpty, field.allSatisfy({ $0 >= "0" && $0 <= "9" }), let value = Int(field), (0...255).contains(value) else { return nil }
            return value
        }
        guard octets.count == 4, (1...223).contains(octets[0]) else { return nil }
        return octets.map(String.init).joined(separator: ".")
    }

    private func resetInputs() {
        input = ControllerInput()
        input.mode = mode
        calculator.reset()
        motionAvailable = false
        motionSuspended = false
        previousOrientation = nil
        resetEpoch += 1
    }

    private func timestamp() -> Int64 {
        Int64((DispatchTime.now().uptimeNanoseconds - clockOrigin) / 1_000_000) + 1
    }

    private func tick() {
        guard active else { return }
        let now = DispatchTime.now().uptimeNanoseconds
        if connected, let ack = lastAck, now - ack >= 500_000_000 {
            connected = false
            status = "未收到回复，正在重连"
            resetInputs()
        }
        if let data = motion.deviceMotion, motionGate.accept(timestamp: data.timestamp, now: now) {
            let orientation = UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .first(where: { $0.activationState == .foregroundActive })?.interfaceOrientation ?? .landscapeRight
            if previousOrientation != nil && previousOrientation != orientation {
                calculator.reset()
                motionAvailable = false
            }
            previousOrientation = orientation
            if QuaternionMotionCalculator.allowsMotion(gravityZ: data.gravity.z) {
                motionSuspended = false
                let q = data.attitude.quaternion
                if let angles = calculator.update(x: q.x, y: q.y, z: q.z, w: q.w, landscapeLeft: orientation == .landscapeLeft) {
                    motionAvailable = true
                    input.steering = QuaternionMotionCalculator.normalize(angle: angles.roll, fullScale: steerFullScale, inverted: steerInvertX)
                    input.roll = QuaternionMotionCalculator.normalize(angle: angles.roll, fullScale: 30, scale: flightScaleX)
                    input.pitch = QuaternionMotionCalculator.normalize(angle: angles.pitch, fullScale: 30, scale: flightScaleY)
                    if flightInvertX { input.roll = -input.roll }
                    if flightInvertY { input.pitch = -input.pitch }
                } else {
                    motionAvailable = false
                }
            } else {
                motionAvailable = false
                motionSuspended = data.gravity.z.isFinite && abs(data.gravity.z) <= 1
            }
        }
        let sampleFresh = motionGate.isFresh(now: now)
        if !sampleFresh { motionSuspended = false }
        if !sampleFresh || !motionAvailable {
            input.steering = 0
            input.roll = 0
            input.pitch = 0
            calculator.reset()
            motionAvailable = false
        }
        if wantsConnection, connection == nil, now >= retryAfter { openConnection() }
        guard ready, !sending, let current = connection else { return }
        do {
            let packet = try InputProtocol.encode(input, timestamp: timestamp())
            sending = true
            current.send(content: packet, completion: .contentProcessed { [weak self, weak current] error in
                Task { @MainActor in
                    guard let self, let current, self.connection === current else { return }
                    self.sending = false
                    if error != nil { self.connectionFailed(current) }
                }
            })
        } catch {
            resetInputs()
            status = "输入无效，已回中"
        }
    }

    private func openConnection() {
        guard active, wantsConnection, let validHost = Self.canonicalIPv4(host) else { return }
        let current = NWConnection(host: NWEndpoint.Host(validHost), port: 7001, using: .udp)
        connection = current
        status = "等待通过\(connectionMethod.label)收到电脑回复；请允许本地网络访问"
        current.stateUpdateHandler = { [weak self, weak current] state in
            Task { @MainActor in
                guard let self, let current, self.active, self.connection === current else { return }
                switch state {
                case .ready:
                    self.ready = true
                    self.receiveAck(current)
                case .waiting:
                    self.connected = false
                    self.ready = false
                    self.status = "检查\(self.connectionMethod.label)系统连接、本地网络权限和电脑 IP"
                    self.resetInputs()
                case .failed:
                    self.connectionFailed(current)
                default:
                    break
                }
            }
        }
        current.start(queue: .main)
    }

    private func receiveAck(_ current: NWConnection) {
        guard active, ready, connection === current, !receiving else { return }
        receiving = true
        current.receiveMessage { [weak self, weak current] data, _, _, error in
            Task { @MainActor in
                guard let self, let current, self.active, self.connection === current else { return }
                self.receiving = false
                if error != nil {
                    self.connectionFailed(current)
                    return
                }
                if data == Data([InputProtocol.ack]) {
                    self.lastAck = DispatchTime.now().uptimeNanoseconds
                    self.connected = true
                    self.status = "已连接"
                }
                self.receiveAck(current)
            }
        }
    }

    private func connectionFailed(_ current: NWConnection) {
        guard connection === current else { return }
        resetInputs()
        closeConnection()
        retryAfter = DispatchTime.now().uptimeNanoseconds + 600_000_000
        status = "连接中断，正在重试；检查接收端和网络权限"
    }

    private func closeConnection() {
        let previous = connection
        connection = nil
        ready = false
        sending = false
        receiving = false
        connected = false
        lastAck = nil
        previous?.cancel()
    }
}
