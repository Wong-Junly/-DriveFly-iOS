import SwiftUI
import UIKit

@main
@MainActor
struct DriveFlyApp: App {
    @StateObject private var model = ControllerModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
                .onAppear { setActive(scenePhase == .active) }
                .onChange(of: scenePhase) { setActive($0 == .active) }
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
                    setActive(false)
                }
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
                    setActive(true)
                }
        }
    }

    private func setActive(_ active: Bool) {
        UIApplication.shared.isIdleTimerDisabled = active
        if active {
            model.activate()
        } else {
            model.deactivate()
        }
    }
}
