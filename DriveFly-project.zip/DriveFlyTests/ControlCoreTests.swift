import Foundation
import XCTest
@testable import DriveFly

final class ControlCoreTests: XCTestCase {
    func testGroundSteeringSweepThroughFullScaleKeepsWireAxesValid() throws {
        for fullScale in stride(from: 30.0, through: 120.0, by: 5.0) {
            for inverted in [false, true] {
                let calculator = QuaternionMotionCalculator()
                _ = update(calculator, rotation(axis: 2, degrees: 0))
                for degrees in stride(from: -180.0, through: 180.0, by: 0.5) {
                    let angles = try XCTUnwrap(update(calculator, rotation(axis: 2, degrees: -degrees)))
                    var input = ControllerInput()
                    input.steering = QuaternionMotionCalculator.normalize(angle: angles.roll, fullScale: fullScale, inverted: inverted)
                    XCTAssertTrue(input.steering.isFinite)
                    XCTAssertTrue((-1...1).contains(input.steering))
                    if abs(degrees) >= fullScale { XCTAssertEqual(abs(input.steering), 1) }
                    let packet = try InputProtocol.encode(input, timestamp: 1)
                    XCTAssertEqual(packet.count, 29)
                    let bits = packet[1..<5].enumerated().reduce(UInt32(0)) { $0 | UInt32($1.element) << UInt32($1.offset * 8) }
                    XCTAssertEqual(Float(bitPattern: bits), input.steering)
                }
            }
        }
    }

    func testGroundSteeringReversalPreservesDeadzoneRangeAndFlightDefault() {
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 31, fullScale: 60, inverted: true), -0.5)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: -31, fullScale: 60, inverted: true), 0.5)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 120, fullScale: 60, inverted: true), -1)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: -120, fullScale: 60, inverted: true), 1)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 2, fullScale: 60, inverted: true), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: .nan, fullScale: 60, inverted: true), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 31, fullScale: 60, inverted: false), 0.5)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 30), 0.5)
    }

    func testConnectionProfilesMigrateLegacyWiFiAndKeepSeparateAddresses() throws {
        let domain = "DriveFlyConnectionTests.\(UUID().uuidString)"
        let preferences = try XCTUnwrap(UserDefaults(suiteName: domain))
        defer { preferences.removePersistentDomain(forName: domain) }
        preferences.set("192.168.1.10", forKey: "host")
        XCTAssertEqual(ConnectionMethod.restore(nil), .wifi)
        XCTAssertEqual(ConnectionMethod.restore("unknown"), .wifi)
        XCTAssertEqual(ConnectionMethod.wifi.savedHost(in: preferences), "192.168.1.10")
        XCTAssertEqual(ConnectionMethod.usb.savedHost(in: preferences), "")
        XCTAssertEqual(ConnectionMethod.bluetooth.savedHost(in: preferences), "")

        preferences.set("172.20.10.2", forKey: ConnectionMethod.usb.hostKey)
        preferences.set("192.168.44.2", forKey: ConnectionMethod.bluetooth.hostKey)
        preferences.set(ConnectionMethod.bluetooth.rawValue, forKey: ConnectionMethod.preferenceKey)
        let selected = ConnectionMethod.restore(preferences.string(forKey: ConnectionMethod.preferenceKey))
        XCTAssertEqual(selected, .bluetooth)
        XCTAssertEqual(selected.savedHost(in: preferences), "192.168.44.2")
        XCTAssertEqual(ConnectionMethod.usb.savedHost(in: preferences), "172.20.10.2")
        XCTAssertEqual(ConnectionMethod.wifi.savedHost(in: preferences), "192.168.1.10")
        preferences.set("", forKey: ConnectionMethod.wifi.hostKey)
        XCTAssertEqual(ConnectionMethod.wifi.savedHost(in: preferences), "")
    }

    func testHorizontalGravityGateRejectsFaceUpFaceDownBoundaryAndInvalidValues() {
        XCTAssertFalse(QuaternionMotionCalculator.allowsMotion(gravityZ: 1))
        XCTAssertFalse(QuaternionMotionCalculator.allowsMotion(gravityZ: -1))
        let boundary = cos(15 * Double.pi / 180)
        XCTAssertFalse(QuaternionMotionCalculator.allowsMotion(gravityZ: boundary))
        XCTAssertFalse(QuaternionMotionCalculator.allowsMotion(gravityZ: -boundary))
        XCTAssertFalse(QuaternionMotionCalculator.allowsMotion(gravityZ: boundary.nextUp))
        XCTAssertTrue(QuaternionMotionCalculator.allowsMotion(gravityZ: boundary.nextDown))
        XCTAssertTrue(QuaternionMotionCalculator.allowsMotion(gravityZ: -boundary.nextDown))
        XCTAssertTrue(QuaternionMotionCalculator.allowsMotion(gravityZ: 0))
        for invalid in [Double.nan, .infinity, -.infinity, 1.01, -1.01] {
            XCTAssertFalse(QuaternionMotionCalculator.allowsMotion(gravityZ: invalid))
        }
    }

    func testResumeAfterHorizontalSuspensionRecalibratesFirstValidPose() throws {
        let calculator = QuaternionMotionCalculator()
        let home = rotation(axis: 0, degrees: 75)
        _ = update(calculator, home)
        let current = multiply(home, rotation(axis: 1, degrees: 16))
        XCTAssertEqual(try XCTUnwrap(update(calculator, current)).pitch, 16, accuracy: 0.000001)
        XCTAssertFalse(QuaternionMotionCalculator.allowsMotion(gravityZ: -1))
        calculator.reset()
        XCTAssertTrue(QuaternionMotionCalculator.allowsMotion(gravityZ: 0.7))
        let resumed = try XCTUnwrap(update(calculator, current))
        XCTAssertEqual(resumed.roll, 0, accuracy: 0.000001)
        XCTAssertEqual(resumed.pitch, 0, accuracy: 0.000001)
        let moved = multiply(current, rotation(axis: 1, degrees: 16))
        XCTAssertEqual(try XCTUnwrap(update(calculator, moved)).pitch, 16, accuracy: 0.000001)
        calculator.calibrate()
        XCTAssertEqual(try XCTUnwrap(update(calculator, moved)).pitch, 0, accuracy: 0.000001)
    }

    func testCollectiveButtonsCancelRestoreAndPreserveGroundInputs() {
        var input = ControllerInput()
        input.mode = .flight
        input.yaw = 1

        input.setCollective(up: true, down: false)
        XCTAssertEqual(input.throttle, 1)
        XCTAssertEqual(input.flaps, 0)
        XCTAssertEqual(input.yaw, 0)
        input.setCollective(up: true, down: true)
        XCTAssertEqual(input.throttle, 0)
        XCTAssertEqual(input.flaps, 0)
        input.setCollective(up: false, down: true)
        XCTAssertEqual(input.throttle, 0)
        XCTAssertEqual(input.flaps, 1)
        input.setCollective(up: false, down: false)
        XCTAssertEqual(input.throttle, 0)
        XCTAssertEqual(input.flaps, 0)

        input.setCollective(up: true, down: true)
        input.setCollective(up: true, down: false)
        XCTAssertEqual(input.throttle, 1)
        XCTAssertEqual(input.flaps, 0)
        input = ControllerInput()
        input.throttle = 0.4
        input.brake = 0.7
        input.setCollective(up: false, down: true)
        XCTAssertEqual(input.throttle, 0.4)
        XCTAssertEqual(input.brake, 0.7)
        XCTAssertEqual(input.flaps, 0)
    }

    func testMotionSamplesMustAdvanceAfterResumeAndExpire() {
        var gate = MotionSampleGate()
        gate.reset(baseline: 12)
        XCTAssertFalse(gate.isFresh(now: 0))
        XCTAssertFalse(gate.accept(timestamp: 12, now: 0))
        XCTAssertFalse(gate.accept(timestamp: 11, now: 0))
        XCTAssertFalse(gate.accept(timestamp: .nan, now: 0))
        XCTAssertFalse(gate.accept(timestamp: .infinity, now: 0))
        XCTAssertFalse(gate.accept(timestamp: -1, now: 0))
        XCTAssertTrue(gate.accept(timestamp: 12.01, now: 100))
        XCTAssertTrue(gate.isFresh(now: 500_000_099))
        XCTAssertFalse(gate.isFresh(now: 500_000_100))
        XCTAssertFalse(gate.accept(timestamp: 12.01, now: 600_000_000))
        XCTAssertFalse(gate.isFresh(now: 600_000_000))
        XCTAssertTrue(gate.accept(timestamp: 12.02, now: 600_000_001))
        XCTAssertTrue(gate.isFresh(now: 600_000_001))
        gate.reset(baseline: 12.02)
        XCTAssertFalse(gate.isFresh(now: 600_000_001))
        XCTAssertFalse(gate.accept(timestamp: 12.02, now: 600_000_002))
        XCTAssertTrue(gate.accept(timestamp: 12.03, now: 600_000_003))
        gate.reset(baseline: nil)
        XCTAssertTrue(gate.accept(timestamp: 0, now: 0))
    }

    func testRacingWirePacketMatchesWindowsProtocol() throws {
        var input = ControllerInput()
        input.steering = -1
        input.throttle = 0.5
        input.brake = 1
        input.clutch = 0
        input.buttons = 0x80000081
        let packet = try InputProtocol.encode(input, timestamp: 0x0102030405060708)
        XCTAssertEqual(packet, Data([
            0x01,
            0x00, 0x00, 0x80, 0xbf,
            0x00, 0x00, 0x00, 0x3f,
            0x00, 0x00, 0x80, 0x3f,
            0x00, 0x00, 0x00, 0x00,
            0x81, 0x00, 0x00, 0x80,
            0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01
        ]))
        XCTAssertEqual(packet.count, 29)
        XCTAssertEqual(InputProtocol.ack, 0x7e)
    }

    func testFlightWirePacketMatchesWindowsProtocol() throws {
        var input = ControllerInput()
        input.mode = .flight
        input.roll = -1
        input.pitch = 0.5
        input.yaw = 1
        input.throttle = 0.25
        input.flaps = 1
        input.buttons = .max
        let packet = try InputProtocol.encode(input, timestamp: .max)
        XCTAssertEqual(packet, Data([
            0x02,
            0x00, 0x00, 0x80, 0xbf,
            0x00, 0x00, 0x00, 0x3f,
            0x00, 0x00, 0x80, 0x3f,
            0x00, 0x00, 0x80, 0x3e,
            0x00, 0x00, 0x80, 0x3f,
            0xff, 0xff, 0xff, 0xff,
            0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x7f
        ]))
        XCTAssertEqual(packet.count, 33)
    }

    func testProtocolRejectsInvalidActiveAxesAndTimestamp() throws {
        for mode in [ControlMode.racing, .flight] {
            let count = mode == .racing ? 4 : 5
            let signedCount = mode == .racing ? 1 : 3
            for axis in 0..<count {
                for invalid in [Float.nan, .infinity, -.infinity, 1.01,
                                axis < signedCount ? -1.01 : -0.01] {
                    var input = ControllerInput()
                    input.mode = mode
                    setAxis(axis, value: invalid, input: &input)
                    XCTAssertThrowsError(try InputProtocol.encode(input, timestamp: 0)) {
                        XCTAssertEqual($0 as? InputProtocol.EncodingError, .invalidAxis)
                    }
                }
                var input = ControllerInput()
                input.mode = mode
                setAxis(axis, value: axis < signedCount ? -1 : 0, input: &input)
                XCTAssertNoThrow(try InputProtocol.encode(input, timestamp: 0))
                setAxis(axis, value: 1, input: &input)
                XCTAssertNoThrow(try InputProtocol.encode(input, timestamp: 0))
            }
        }
        XCTAssertThrowsError(try InputProtocol.encode(ControllerInput(), timestamp: -1)) {
            XCTAssertEqual($0 as? InputProtocol.EncodingError, .invalidTimestamp)
        }
        var input = ControllerInput()
        input.roll = .nan
        XCTAssertNoThrow(try InputProtocol.encode(input, timestamp: 0))
        input = ControllerInput()
        input.mode = .flight
        input.steering = .nan
        XCTAssertNoThrow(try InputProtocol.encode(input, timestamp: 0))
    }

    func testLandscapeAxesAndCombinedRotation() throws {
        let calculator = QuaternionMotionCalculator()
        _ = update(calculator, rotation(axis: 2, degrees: 0))
        let rightRoll = try XCTUnwrap(update(calculator, rotation(axis: 2, degrees: -30)))
        XCTAssertEqual(rightRoll.roll, 30, accuracy: 0.000001)
        XCTAssertEqual(rightRoll.pitch, 0, accuracy: 0.000001)
        let pitch = try XCTUnwrap(update(calculator, rotation(axis: 1, degrees: 30)))
        XCTAssertEqual(pitch.pitch, 30, accuracy: 0.000001)
        XCTAssertEqual(try XCTUnwrap(update(calculator, rotation(axis: 1, degrees: 30),
                                           landscapeLeft: false)).pitch, -30, accuracy: 0.000001)
        let combined = multiply(rotation(axis: 2, degrees: -16), rotation(axis: 1, degrees: 16))
        let result = try XCTUnwrap(update(calculator, combined))
        XCTAssertEqual(result.roll, 16, accuracy: 0.000001)
        XCTAssertEqual(result.pitch, 16, accuracy: 0.000001)
    }

    func testArbitraryCalibrationQuaternionSignAndReset() throws {
        let calculator = QuaternionMotionCalculator()
        let home = multiply(rotation(axis: 0, degrees: 75), rotation(axis: 2, degrees: 179))
        let neutral = try XCTUnwrap(update(calculator, home))
        XCTAssertEqual(neutral.roll, 0, accuracy: 0.000001)
        XCTAssertEqual(neutral.pitch, 0, accuracy: 0.000001)
        let current = multiply(home, rotation(axis: 1, degrees: 16))
        let angles = try XCTUnwrap(update(calculator, current))
        XCTAssertEqual(angles.roll, 0, accuracy: 0.000001)
        XCTAssertEqual(angles.pitch, 16, accuracy: 0.000001)
        let negated = try XCTUnwrap(update(calculator, current.map { -$0 }))
        XCTAssertEqual(negated.roll, angles.roll, accuracy: 0.000001)
        XCTAssertEqual(negated.pitch, angles.pitch, accuracy: 0.000001)
        calculator.calibrate()
        XCTAssertEqual(try XCTUnwrap(update(calculator, current)).pitch, 0, accuracy: 0.000001)
        calculator.reset()
        XCTAssertEqual(try XCTUnwrap(update(calculator, home)).pitch, 0, accuracy: 0.000001)
    }

    func testWrapAndInvalidSamplesKeepCalibration() throws {
        let calculator = QuaternionMotionCalculator()
        _ = update(calculator, rotation(axis: 2, degrees: 170))
        let current = rotation(axis: 2, degrees: -174)
        XCTAssertEqual(try XCTUnwrap(update(calculator, current)).roll, -16, accuracy: 0.000001)
        XCTAssertNil(calculator.update(x: .nan, y: 0, z: 0, w: 1, landscapeLeft: true))
        XCTAssertNil(calculator.update(x: 0, y: .infinity, z: 0, w: 1, landscapeLeft: true))
        XCTAssertNil(calculator.update(x: 0, y: 0, z: 0, w: 0, landscapeLeft: true))
        XCTAssertEqual(try XCTUnwrap(update(calculator, current.map { $0 * 2 })).roll,
                       -16, accuracy: 0.000001)
        calculator.calibrate()
        XCTAssertEqual(try XCTUnwrap(update(calculator, current)).roll, 0, accuracy: 0.000001)
    }

    func testDeadzoneFullScaleAndFailClosedNormalization() {
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 2, fullScale: 30), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: -1.9, fullScale: 30), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 30), 0.5)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: -16, fullScale: 30), -0.5)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 31, fullScale: 60), 0.5)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 30, fullScale: 30), 1)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: -90, fullScale: 30), -1)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: .nan, fullScale: 30), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 2), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: .infinity), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 30, deadzone: -1), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 30, scale: 1), 0.5)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 30, scale: 0.5), 0.25)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 30, scale: 2), 1)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 24, fullScale: 30, scale: 2), 1)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: -16, fullScale: 30, scale: 0.5), -0.25)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 2, fullScale: 30, scale: 2), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: -1.9, fullScale: 30, scale: 2), 0)
        for invalid in [Double.nan, .infinity, -.infinity, 0, -1] {
            XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 30, scale: invalid), 0)
        }
    }

    private func setAxis(_ index: Int, value: Float, input: inout ControllerInput) {
        switch (input.mode, index) {
        case (.racing, 0): input.steering = value
        case (.racing, 1), (.flight, 3): input.throttle = value
        case (.racing, 2): input.brake = value
        case (.racing, 3): input.clutch = value
        case (.flight, 0): input.roll = value
        case (.flight, 1): input.pitch = value
        case (.flight, 2): input.yaw = value
        case (.flight, 4): input.flaps = value
        default: XCTFail("Invalid test axis")
        }
    }

    private func rotation(axis: Int, degrees: Double) -> [Double] {
        let half = degrees * .pi / 360
        var q = [0.0, 0.0, 0.0, cos(half)]
        q[axis] = sin(half)
        return q
    }

    private func multiply(_ a: [Double], _ b: [Double]) -> [Double] {
        [a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
         a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
         a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
         a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]]
    }

    private func update(_ calculator: QuaternionMotionCalculator, _ q: [Double],
                        landscapeLeft: Bool = true) -> MotionAngles? {
        // Fixtures describe physical device to reference rotations, Core Motion returns the inverse.
        calculator.update(x: -q[0], y: -q[1], z: -q[2], w: q[3], landscapeLeft: landscapeLeft)
    }
}

#if canImport(UIKit)
import Combine

final class ControllerModelTests: XCTestCase {
    @MainActor
    func testMotionSettingsAcceptRepeatedBoundariesAndRejectInvalidValues() {
        let preferences = UserDefaults.standard
        let keys = ["steerFullScale", "flightScaleX", "flightScaleY"]
        let saved = keys.map { preferences.object(forKey: $0) }
        defer {
            for (index, key) in keys.enumerated() {
                if let value = saved[index] { preferences.set(value, forKey: key) }
                else { preferences.removeObject(forKey: key) }
            }
        }
        let model = ControllerModel()
        let settings: [(String, KeyPath<ControllerModel, Double>, (Double) -> Void, ClosedRange<Double>, Double, Published<Double>.Publisher)] = [
            ("steerFullScale", \ControllerModel.steerFullScale, model.setSteerFullScale, 30...120, 60, model.$steerFullScale),
            ("flightScaleX", \ControllerModel.flightScaleX, model.setFlightScaleX, 0.25...2, 1, model.$flightScaleX),
            ("flightScaleY", \ControllerModel.flightScaleY, model.setFlightScaleY, 0.25...2, 1, model.$flightScaleY)
        ]
        for (key, path, setValue, range, fallback, publisher) in settings {
            var published: [Double] = []
            let subscription = publisher.sink { published.append($0) }
            for _ in 0..<10 {
                for value in [range.upperBound, range.lowerBound, fallback, range.upperBound] {
                    setValue(value)
                    XCTAssertEqual(model[keyPath: path], value)
                    XCTAssertEqual(preferences.double(forKey: key), value)
                }
            }
            for invalid in [Double.nan, .infinity, -.infinity] {
                setValue(invalid)
                XCTAssertEqual(model[keyPath: path], fallback)
                XCTAssertEqual(preferences.double(forKey: key), fallback)
            }
            setValue(range.upperBound + 1)
            XCTAssertEqual(model[keyPath: path], range.upperBound)
            setValue(range.lowerBound - 1)
            XCTAssertEqual(model[keyPath: path], range.lowerBound)
            XCTAssertTrue(published.allSatisfy { $0.isFinite && range.contains($0) })
            subscription.cancel()
        }
    }

    @MainActor
    func testFlightRudderButtonsHoldReleaseAndResetWithMode() {
        let model = ControllerModel()
        model.disconnect()
        model.setMode(.flight)
        model.activate()
        defer { model.deactivate() }
        XCTAssertTrue(model.controlsEnabled, "The test host must be in the foreground.")
        guard model.controlsEnabled else { return }

        model.setButton(5, pressed: true)
        XCTAssertEqual(model.input.buttons, 0x10)
        model.setButton(6, pressed: true)
        XCTAssertEqual(model.input.buttons, 0x30)
        model.setButton(5, pressed: false)
        XCTAssertEqual(model.input.buttons, 0x20)
        model.setButton(6, pressed: false)
        XCTAssertEqual(model.input.buttons, 0)
        model.setButton(6, pressed: true)
        model.setButton(5, pressed: true)
        model.setButton(6, pressed: false)
        XCTAssertEqual(model.input.buttons, 0x10)
        model.setButton(6, pressed: true)

        model.setMode(.racing)
        XCTAssertEqual(model.input.buttons, 0)
        model.setMode(.flight)
        XCTAssertEqual(model.input.buttons, 0)
        model.setButton(5, pressed: true)
        model.setButton(6, pressed: true)
        model.deactivate()
        XCTAssertEqual(model.input.buttons, 0)
        model.setButton(5, pressed: true)
        XCTAssertEqual(model.input.buttons, 0)
    }

    @MainActor
    func testModeSwitchWorksWithoutConnectionAndKeepsPacketModeInSync() throws {
        let model = ControllerModel()
        XCTAssertFalse(model.controlsEnabled)
        XCTAssertFalse(model.connected)
        let epoch = model.resetEpoch

        model.setMode(.flight)
        XCTAssertEqual(model.mode, .flight)
        XCTAssertEqual(model.input.mode, .flight)
        XCTAssertEqual(model.resetEpoch, epoch + 1)
        let flight = try InputProtocol.encode(model.input, timestamp: 1)
        XCTAssertEqual(flight.first, 2)
        XCTAssertEqual(flight.count, 33)
        model.setMode(.flight)
        XCTAssertEqual(model.resetEpoch, epoch + 1)

        model.setMode(.racing)
        XCTAssertEqual(model.mode, .racing)
        XCTAssertEqual(model.input.mode, .racing)
        XCTAssertEqual(model.resetEpoch, epoch + 2)
        let ground = try InputProtocol.encode(model.input, timestamp: 2)
        XCTAssertEqual(ground.first, 1)
        XCTAssertEqual(ground.count, 29)
        XCTAssertEqual(model.input.buttons, 0)
    }

    @MainActor
    func testGroundReversalDefaultAndSavedOffChoiceAreIndependentOfFlight() {
        let preferences = UserDefaults.standard
        let saved = preferences.object(forKey: "steerInvertX")
        defer {
            if let saved { preferences.set(saved, forKey: "steerInvertX") }
            else { preferences.removeObject(forKey: "steerInvertX") }
        }
        preferences.removeObject(forKey: "steerInvertX")
        let model = ControllerModel()
        XCTAssertTrue(model.steerInvertX)
        let flightX = model.flightInvertX
        let flightY = model.flightInvertY
        model.steerInvertX = false
        XCTAssertEqual(model.input.steering, 0)
        XCTAssertFalse(ControllerModel().steerInvertX)
        XCTAssertEqual(model.flightInvertX, flightX)
        XCTAssertEqual(model.flightInvertY, flightY)
    }
}
#endif
