import Foundation
import XCTest
@testable import DriveFly

final class ControlCoreTests: XCTestCase {
    func testMotionSamplesMustAdvanceAfterResumeAndExpire() {
        var gate = MotionSampleGate()
        gate.reset(baseline: 12)
        XCTAssertFalse(gate.isFresh(now: 0))
        XCTAssertFalse(gate.accept(timestamp: 12, now: 0))
        XCTAssertFalse(gate.accept(timestamp: 11, now: 0))
        XCTAssertFalse(gate.accept(timestamp: .nan, now: 0))
        XCTAssertFalse(gate.accept(timestamp: .infinity, now: 0))
        XCTAssertFalse(gate.accept(timestamp: -1, now: 0))
        XCTAssertTrue(gate.accept(timestamp: 12.01, now: 100))
        XCTAssertTrue(gate.isFresh(now: 500_000_099))
        XCTAssertFalse(gate.isFresh(now: 500_000_100))
        XCTAssertFalse(gate.accept(timestamp: 12.01, now: 600_000_000))
        XCTAssertFalse(gate.isFresh(now: 600_000_000))
        XCTAssertTrue(gate.accept(timestamp: 12.02, now: 600_000_001))
        XCTAssertTrue(gate.isFresh(now: 600_000_001))
        gate.reset(baseline: 12.02)
        XCTAssertFalse(gate.isFresh(now: 600_000_001))
        XCTAssertFalse(gate.accept(timestamp: 12.02, now: 600_000_002))
        XCTAssertTrue(gate.accept(timestamp: 12.03, now: 600_000_003))
        gate.reset(baseline: nil)
        XCTAssertTrue(gate.accept(timestamp: 0, now: 0))
    }

    func testRacingWirePacketMatchesWindowsProtocol() throws {
        var input = ControllerInput()
        input.steering = -1
        input.throttle = 0.5
        input.brake = 1
        input.clutch = 0
        input.buttons = 0x80000081
        let packet = try InputProtocol.encode(input, timestamp: 0x0102030405060708)
        XCTAssertEqual(packet, Data([
            0x01,
            0x00, 0x00, 0x80, 0xbf,
            0x00, 0x00, 0x00, 0x3f,
            0x00, 0x00, 0x80, 0x3f,
            0x00, 0x00, 0x00, 0x00,
            0x81, 0x00, 0x00, 0x80,
            0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01
        ]))
        XCTAssertEqual(packet.count, 29)
        XCTAssertEqual(InputProtocol.ack, 0x7e)
    }

    func testFlightWirePacketMatchesWindowsProtocol() throws {
        var input = ControllerInput()
        input.mode = .flight
        input.roll = -1
        input.pitch = 0.5
        input.yaw = 1
        input.throttle = 0.25
        input.flaps = 1
        input.buttons = .max
        let packet = try InputProtocol.encode(input, timestamp: .max)
        XCTAssertEqual(packet, Data([
            0x02,
            0x00, 0x00, 0x80, 0xbf,
            0x00, 0x00, 0x00, 0x3f,
            0x00, 0x00, 0x80, 0x3f,
            0x00, 0x00, 0x80, 0x3e,
            0x00, 0x00, 0x80, 0x3f,
            0xff, 0xff, 0xff, 0xff,
            0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x7f
        ]))
        XCTAssertEqual(packet.count, 33)
    }

    func testProtocolRejectsInvalidActiveAxesAndTimestamp() throws {
        for mode in [ControlMode.racing, .flight] {
            let count = mode == .racing ? 4 : 5
            let signedCount = mode == .racing ? 1 : 3
            for axis in 0..<count {
                for invalid in [Float.nan, .infinity, -.infinity, 1.01,
                                axis < signedCount ? -1.01 : -0.01] {
                    var input = ControllerInput()
                    input.mode = mode
                    setAxis(axis, value: invalid, input: &input)
                    XCTAssertThrowsError(try InputProtocol.encode(input, timestamp: 0)) {
                        XCTAssertEqual($0 as? InputProtocol.EncodingError, .invalidAxis)
                    }
                }
                var input = ControllerInput()
                input.mode = mode
                setAxis(axis, value: axis < signedCount ? -1 : 0, input: &input)
                XCTAssertNoThrow(try InputProtocol.encode(input, timestamp: 0))
                setAxis(axis, value: 1, input: &input)
                XCTAssertNoThrow(try InputProtocol.encode(input, timestamp: 0))
            }
        }
        XCTAssertThrowsError(try InputProtocol.encode(ControllerInput(), timestamp: -1)) {
            XCTAssertEqual($0 as? InputProtocol.EncodingError, .invalidTimestamp)
        }
        var input = ControllerInput()
        input.roll = .nan
        XCTAssertNoThrow(try InputProtocol.encode(input, timestamp: 0))
        input = ControllerInput()
        input.mode = .flight
        input.steering = .nan
        XCTAssertNoThrow(try InputProtocol.encode(input, timestamp: 0))
    }

    func testLandscapeAxesAndCombinedRotation() throws {
        let calculator = QuaternionMotionCalculator()
        _ = update(calculator, rotation(axis: 2, degrees: 0))
        let rightRoll = try XCTUnwrap(update(calculator, rotation(axis: 2, degrees: -30)))
        XCTAssertEqual(rightRoll.roll, 30, accuracy: 0.000001)
        XCTAssertEqual(rightRoll.pitch, 0, accuracy: 0.000001)
        let pitch = try XCTUnwrap(update(calculator, rotation(axis: 1, degrees: 30)))
        XCTAssertEqual(pitch.pitch, 30, accuracy: 0.000001)
        XCTAssertEqual(try XCTUnwrap(update(calculator, rotation(axis: 1, degrees: 30),
                                           landscapeLeft: false)).pitch, -30, accuracy: 0.000001)
        let combined = multiply(rotation(axis: 2, degrees: -16), rotation(axis: 1, degrees: 16))
        let result = try XCTUnwrap(update(calculator, combined))
        XCTAssertEqual(result.roll, 16, accuracy: 0.000001)
        XCTAssertEqual(result.pitch, 16, accuracy: 0.000001)
    }

    func testArbitraryCalibrationQuaternionSignAndReset() throws {
        let calculator = QuaternionMotionCalculator()
        let home = multiply(rotation(axis: 0, degrees: 75), rotation(axis: 2, degrees: 179))
        let neutral = try XCTUnwrap(update(calculator, home))
        XCTAssertEqual(neutral.roll, 0, accuracy: 0.000001)
        XCTAssertEqual(neutral.pitch, 0, accuracy: 0.000001)
        let current = multiply(home, rotation(axis: 1, degrees: 16))
        let angles = try XCTUnwrap(update(calculator, current))
        XCTAssertEqual(angles.roll, 0, accuracy: 0.000001)
        XCTAssertEqual(angles.pitch, 16, accuracy: 0.000001)
        let negated = try XCTUnwrap(update(calculator, current.map { -$0 }))
        XCTAssertEqual(negated.roll, angles.roll, accuracy: 0.000001)
        XCTAssertEqual(negated.pitch, angles.pitch, accuracy: 0.000001)
        calculator.calibrate()
        XCTAssertEqual(try XCTUnwrap(update(calculator, current)).pitch, 0, accuracy: 0.000001)
        calculator.reset()
        XCTAssertEqual(try XCTUnwrap(update(calculator, home)).pitch, 0, accuracy: 0.000001)
    }

    func testWrapAndInvalidSamplesKeepCalibration() throws {
        let calculator = QuaternionMotionCalculator()
        _ = update(calculator, rotation(axis: 2, degrees: 170))
        let current = rotation(axis: 2, degrees: -174)
        XCTAssertEqual(try XCTUnwrap(update(calculator, current)).roll, -16, accuracy: 0.000001)
        XCTAssertNil(calculator.update(x: .nan, y: 0, z: 0, w: 1, landscapeLeft: true))
        XCTAssertNil(calculator.update(x: 0, y: .infinity, z: 0, w: 1, landscapeLeft: true))
        XCTAssertNil(calculator.update(x: 0, y: 0, z: 0, w: 0, landscapeLeft: true))
        XCTAssertEqual(try XCTUnwrap(update(calculator, current.map { $0 * 2 })).roll,
                       -16, accuracy: 0.000001)
        calculator.calibrate()
        XCTAssertEqual(try XCTUnwrap(update(calculator, current)).roll, 0, accuracy: 0.000001)
    }

    func testDeadzoneFullScaleAndFailClosedNormalization() {
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 2, fullScale: 30), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: -1.9, fullScale: 30), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 30), 0.5)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: -16, fullScale: 30), -0.5)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 31, fullScale: 60), 0.5)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 30, fullScale: 30), 1)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: -90, fullScale: 30), -1)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: .nan, fullScale: 30), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 2), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: .infinity), 0)
        XCTAssertEqual(QuaternionMotionCalculator.normalize(angle: 16, fullScale: 30, deadzone: -1), 0)
    }

    private func setAxis(_ index: Int, value: Float, input: inout ControllerInput) {
        switch (input.mode, index) {
        case (.racing, 0): input.steering = value
        case (.racing, 1), (.flight, 3): input.throttle = value
        case (.racing, 2): input.brake = value
        case (.racing, 3): input.clutch = value
        case (.flight, 0): input.roll = value
        case (.flight, 1): input.pitch = value
        case (.flight, 2): input.yaw = value
        case (.flight, 4): input.flaps = value
        default: XCTFail("Invalid test axis")
        }
    }

    private func rotation(axis: Int, degrees: Double) -> [Double] {
        let half = degrees * .pi / 360
        var q = [0.0, 0.0, 0.0, cos(half)]
        q[axis] = sin(half)
        return q
    }

    private func multiply(_ a: [Double], _ b: [Double]) -> [Double] {
        [a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
         a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
         a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
         a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]]
    }

    private func update(_ calculator: QuaternionMotionCalculator, _ q: [Double],
                        landscapeLeft: Bool = true) -> MotionAngles? {
        // Fixtures describe physical device to reference rotations, Core Motion returns the inverse.
        calculator.update(x: -q[0], y: -q[1], z: -q[2], w: q[3], landscapeLeft: landscapeLeft)
    }
}
