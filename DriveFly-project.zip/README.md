# DriveFly iOS

## iOS 0.2.1（Build 3）更新状态

飞行控制区保留原三栏六个按钮，下方新增“机头左转”和“机头右转”两个按住按钮。它们控制机头方向舵，不是载具侧移；按住发送逻辑按钮 5／6，松手、触摸取消、离开界面或切换模式释放。两个按钮的按住状态独立，由配套 Windows 接收端处理同时按住时回中。

此次手机端需要配套 **Windows 0.4.1 Xbox 接收端**：机头左转／右转映射 Xbox 右摇杆 X（RX）向左／右，按住为满行程；两个同时按住或均松开回中，松开一侧后恢复仍按住的另一侧。关闭游戏自由观察时用于截图中的踏板／方向舵；自由观察模式会按游戏设置控制视角。旧 Windows 0.4.0 不处理新增方向舵按钮。手机协议沿用既有按钮位，不增加 yaw 状态或传输字段。顶部独立模式按钮和地面转向反转修复继续保留。

本地 6 个 Swift 文件语法解析及 Xcode 工程结构检查已通过，新增模型测试覆盖按下、同时按下、逐个释放、切模式及停用清零。0.2.1 尚未执行 Apple 编译或模型测试，云端编译验证由主任务安排；下面 0.2.0 的成功结果仅作为历史记录。

## iOS 0.2.0（Build 2）历史验证

本次只更新手机端，电脑继续使用已安装的 **DriveFly Windows 0.4.0 Xbox 版**，无需重新安装电脑端。

顶部模式选择改为两个独立按钮：“地面载具”和“飞机”。每个按钮的触控高度至少 44 点，选中项显示勾选。点击“飞机”后应显示总距升高／降低、攻击和对抗装置等飞行按钮；点击“地面载具”返回油门、刹车布局。模式按钮不受电脑连接状态或手机接近水平的限制。

设置新增“地面转向反转”，默认开启，用于纠正用户实测的相反方向。若倾斜与车辆转向仍相反，关闭此项。选择会单独保存，不影响飞行 X/Y 反转。首次更新后请先在 Windows 手柄属性页检查左右方向。

旧分段模式选择器的源码未发现明确错误；本次调整提供更大的明确点击区域，不能据此宣称已确诊或解决所有真机触摸问题。

本次 0.2.0（Build 2）已通过 [GitHub Actions 构建](https://github.com/Wong-Junly/-DriveFly-iOS/actions/runs/38137245707)，对应提交 `76bd9f9fc3c468508ce89cd5db73c946cee0b5f8`。Xcode 16.4 下，13 项 Swift 核心测试与 15 项模拟器测试（13 项核心＋2 项 ControllerModel 测试）均为 0 失败；Release 真机编译及 `codesign --verify --strict` 也已通过。交付文件 `DriveFly-iOS-0.2.0.ipa` 已下载并核对版本 0.2.0、Build 2、ARM64 和应用 ID。

更新位于 [草稿 PR #1](https://github.com/Wong-Junly/-DriveFly-iOS/pull/1)，尚未合并到 main；旧版 main 的工作流或产物不代表本次更新。测试通过不代表 iPhone 已安装新版；下载后仍须重签并安装，真实 iPhone 点按和游戏控制仍待实测。

已核对的远程第 5 次成功运行（ID `38122131442`）仍为 0.1 源码，与此前本地源码相同。它不能验证本次 0.2.0 更新，也不代表手机已安装此次更新。

本仓库单独维护 iOS 客户端。安卓源码放在另一个 `DriveFly-Android` 仓库，两端共用现有 Windows 接收程序和通信协议。

`DriveFly-iOS-GitHub.zip` 解压后的内容直接放在仓库根目录，根目录应有 `DriveFly`、`DriveFlyTests`、`DriveFly.xcodeproj`、`Package.swift` 和 `build-macos.sh`。现有 `Wong-Junly/-DriveFly-iOS` 可继续使用网页上传修复包：本次覆盖根目录的 `DriveFly-project.zip`，并用本包的 `main.yml` 更新现有 `.github/workflows/main.yml` 后提交；不要同时添加第二套工作流。

## Wi-Fi、USB 和蓝牙网络

设置中可选择 **Wi-Fi、USB 网络、蓝牙网络**，每种方式分别保存电脑的 IPv4 地址，旧版本保存的 IP 自动作为 Wi-Fi 地址。切换方式会释放输入、断开旧连接，再使用所选方式的地址；空地址不会连接。界面只有收到 Windows 接收端的回复后才显示“已连接”。

USB 与蓝牙使用 iPhone 的系统个人热点网络；先完成下面的系统连接，再在 DriveFly 选择方式和填写地址。App 的选择不会替你打开热点、配对或加入网络，数据仍通过现有 UDP 7001 传输。

| 方式 | 先完成的系统操作 | 在 DriveFly 填写 |
|---|---|---|
| Wi-Fi | 手机与 Windows 连接同一 Wi-Fi 或局域网 | 电脑在这个局域网中的 IPv4 |
| USB 网络 | iPhone 开启个人热点，USB 连接并信任 Windows；电脑安装 Apple 设备或 iTunes | 电脑的 iPhone USB 网络适配器 IPv4 |
| 蓝牙网络 | iPhone 开启个人热点，与 Windows 配对，然后由 Windows 加入个人局域网（PAN） | 电脑的蓝牙网络适配器 IPv4 |

iPhone 个人热点需要启用蜂窝数据，且运营商套餐支持个人热点；电脑也可能通过手机上网并使用流量。这适用于 USB 和蓝牙网络。[Apple 个人热点说明](https://support.apple.com/zh-cn/111785)

### USB 网络连接

1. Windows 安装“Apple 设备”或 iTunes。iPhone 打开“设置 → 个人热点 → 允许其他人加入”。
2. 用能传数据的 USB 线连接手机与电脑，解锁手机，并按系统提示允许连接、信任电脑。
3. Windows 的 iPhone 网络适配器获得 IPv4 后，在 DriveFly 选择“USB 网络”并填入该适配器的**电脑地址**。不要填写手机地址或网关地址。

以上系统步骤见 [Apple USB 个人热点指南](https://support.apple.com/zh-cn/guide/iphone/iph45447ca6/ios)。

### 蓝牙网络连接

1. iPhone 打开个人热点的“允许其他人加入”，保持“设置 → 蓝牙”打开；Windows 打开蓝牙并与 iPhone 配对。
2. Windows 11 打开“设置 → 蓝牙和设备 → 设备”，展开 iPhone，选择个人局域网（PAN）的“加入”，再以“接入点”连接。Windows 10 可在蓝牙托盘菜单中选择“加入个人区域网络”，右击手机并选择“连接时使用 → 接入点”。仅显示“已配对”还没有建立蓝牙网络。[微软 PAN 连接指南](https://support.microsoft.com/en-us/windows/hardware/bluetooth/connect-to-a-bluetooth-network-in-windows)
3. Windows 蓝牙网络适配器获得 IPv4 后，在 DriveFly 选择“蓝牙网络”，填入该适配器的电脑地址。

Windows 接收端需持续运行，防火墙允许当前网络上的 UDP 7001。若没有“加入 PAN”或网络适配器没有地址，先解决系统网络连接；在 App 里切换方式不会修复系统建链问题。三种方式可以切换使用，不会同时建立三条控制会话。USB 与蓝牙的实际设备连接、延迟和游戏响应尚未实测。

## WARDOGS 地面与飞行布局（2026-10-11 更新）

手机横握。地面固定使用陀螺仪转向：默认左刹车、右油门，设置可互换并保存；中上解锁载具、正中部署补给箱、中下对抗装置。踏板和按钮松手释放。

飞行按用户设计使用三栏、各上下两个按住按钮：

| 位置 | 左侧 | 中间 | 右侧 |
|---|---|---|---|
| 上半 | 总距升高 | 解锁载具（L） | 攻击 |
| 下半 | 总距降低 | 部署补给箱（G） | 对抗装置 |

左右倾斜控制机身横滚，前后倾斜控制俯仰。左侧总距使用按钮，不使用滑块；按住生效、松手释放，上下同时按住抵消，松开一个后恢复仍按住的另一个。0.2.1 在三栏下方增加机头左转／右转；既有 yaw 字段保持中位，方向舵改由新增按钮发送给配套 Windows 接收端。

设置中可分别修改飞行 X/Y 反转及映射比例：X 是左右倾斜，Y 是前后倾斜，均默认不反转、100%，比例范围 25%–200%。比例越大，同样倾斜角度产生的输出越大，达到满量程后不继续增大；两轴偏好独立保存。这里的 X/Y 是手机倾斜方向，电脑输出为下面的 Xbox 左摇杆轴。

屏幕平面距水平面 15° 以内时暂停体感，正面朝上、朝下均生效：转向、横滚、俯仰回中，屏幕按钮和总距仍可操作。抬起后的首个有效姿态重新回中；恢复后可手动校准。

以下为 Windows 0.4.0 Xbox 版输出，手机通信协议保持兼容：

| 操作 | 地面输出 | 飞行输出 |
|---|---|---|
| 左右倾斜 | Xbox 左摇杆 X（LX），转向 | Xbox 左摇杆 X（LX），横滚 |
| 前后倾斜 | 未使用 | Xbox 左摇杆 Y（LY），俯仰 |
| 地面油门／刹车 | Xbox RT／LT | 未使用 |
| 总距升高／降低 | 未使用 | Xbox RT／LT，按住满量程，释放 0 |
| 解锁载具 | 键盘 L | 键盘 L |
| 部署补给箱 | 键盘 G | 键盘 G |
| 对抗装置 | Xbox 方向键上（DPAD_UP） | Xbox 方向键上（DPAD_UP） |
| 攻击 | 未使用 | Xbox RT |

飞行总距升高和攻击共用 RT，游戏收到的是同一个扳机输入，不能同时区分这两个动作。

在 WARDOGS 中关闭 HOTAS，使用普通手柄（Gamepad）控制。解锁、补给分别绑定键盘 L、G，其余操作使用表中的 Xbox 输入。Windows 0.4.0 已通过真实 XInput 识别及回中检查；游戏中同时使用手柄和 L/G 的效果仍需实测。

L/G 按住时按下、松手时释放；断线超过 500ms、正常关闭或输出失败时清理已按住的键。两种模式的 L/G 均只输出键盘按键，不重复输出 Xbox 按钮。键盘输入进入当前前台程序；若游戏以管理员身份运行，接收端需使用相同权限，见 [微软 SendInput 文档](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput)。强制结束进程不能保证释放。

本次只需更新 iOS，保留 Windows 0.4.0 Xbox 接收端。旧版 iOS 已由用户安装；本次 0.2.0 已通过 GitHub Actions 核心测试、模拟器模型测试和真机编译，仍需重签并安装新 IPA。传输字段名 throttle/flaps 为兼容而保留，在新版飞行界面中分别对应总距升高／降低。

iOS 版与安卓版本使用同一个 Windows 接收端。iPhone 需要 iOS 16 或更新版本；游戏电脑使用 DriveFly Windows 0.4.0 Xbox 程序及 ViGEmBus 驱动。

历史记录：GitHub Actions 第 4 次运行曾成功生成旧版 IPA 和编译日志（2026-10-11 用户截图确认），用户已安装旧版。此次更新应下载 0.2.0 新运行的 `DriveFly-iOS-to-resign` 产物，在 Windows 重签并重新安装；不要重装旧运行的产物。

网页上传目录失败时，可使用另行提供的 `DriveFly-iOS-网页上传修复包.zip`：上传包内的 `DriveFly-project.zip` 文件本身，并用配套 `main.yml` 替换现有工作流。Actions 会解包并一次检查全部必需文件，具体步骤见修复包里的使用说明。

## 1. 用 GitHub Actions 编译（推荐）

1. 在 [GitHub](https://github.com/) 创建自己的仓库，例如 `DriveFly-iOS`，勾选 **Add a README file** 后创建。公开或私有都可用；公开会公开源码，私有使用账号的 Actions 额度并可能有超额费用。[官方用量说明](https://docs.github.com/en/billing/concepts/product-billing/github-actions)
2. 把这个目录内的完整文件夹和文件拖到上传网页，等列表出现 `DriveFly/ControlCore.swift`、`DriveFlyTests/ControlCoreTests.swift` 和 `DriveFly.xcodeproj/project.pbxproj` 等路径后提交。回到 Code，确认根目录有 `DriveFly`、`DriveFlyTests`、`DriveFly.xcodeproj`、`build-macos.sh` 和 `Package.swift`。不要再套 `DriveFlyIOS` 文件夹。聊天中提供的普通 `DriveFly-iOS-GitHub.zip` 已按这个结构打包。
3. 如果网页上传漏了 `.github`，用 **Add file → Create new file**，创建 `.github/workflows/build-ios.yml`，粘贴包里该文件内容并提交。
4. 打开仓库 **Actions → Build DriveFly iOS → Run workflow**，选择默认分支并运行。工作流必须先放在默认分支。[官方操作步骤](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow)
5. 成功后，在运行摘要的 **Artifacts** 下载 **DriveFly-iOS-to-resign**，解压 ZIP 取得 `DriveFly-iOS.ipa`。产物保留 7 天，请及时下载。

更新后的工作流可由 Pull Request 自动启动，也可在 Actions 手动启动，使用 `macos-15` 标准编译机，依次运行 `swift test` 的 13 项核心测试、Xcode iPhone 模拟器中的 15 项测试（13 项核心＋2 项模型），再编译真机 App，任一失败即停止；不需要配置 Apple 账号、密码、签名证书或自定义 Secrets。生成的 IPA 必须按下一节在 Windows 重签安装。它的完整性签名不包含 Apple 安装授权。

构建入口会一次检查全部必需文件。失败时先看日志中的明确错误；网页上传修复工作流还会把测试和编译完整日志保存到 `DriveFly-iOS-build-log` 产物。本次 0.2.0 的测试和真机编译已通过，见 [当前构建结果](https://github.com/Wong-Junly/-DriveFly-iOS/actions/runs/38137245707)；旧版成功结果保留为历史记录。

## 备用：在自己的 Mac 或云 Mac 编译

选用已安装完整 Xcode 的 Mac，建议 Xcode 16 或更新版本，并能使用终端及下载生成的文件。云 Mac 无需连接你的 iPhone，也无需登录你的 Apple 账号。

把 `DriveFlyIOS` 工程目录传到自己的 Mac，打开终端并进入该目录。例如目录放在桌面时：

```bash
cd "$HOME/Desktop/DriveFlyIOS"
xcodebuild -version
xcrun --sdk iphoneos --show-sdk-path
bash build-macos.sh
```

如果 `xcodebuild` 显示只有 Command Line Tools 或找不到 SDK，需要先在 Xcode“Settings → Locations → Command Line Tools”选择完整 Xcode，并完成该机器要求的首次启动设置。租用前确认服务提供这些条件。

脚本依次运行 13 项纯 Swift 核心测试、Xcode iPhone 模拟器中的 15 项测试（13 项核心＋2 项模型），再使用 `generic/platform=iOS` 编译完整真机 App。全部成功后生成：

```text
DriveFlyIOS/build/DriveFly-iOS.ipa
```

把 IPA 下载回 Windows。脚本的本地完整性签名不包含 Apple 安装授权，**这个 IPA 不能直接点开安装，必须在下一步重新签名**。构建失败时保留原有 IPA；请保存终端错误用于排查。

## 2. 在 Windows 重签并安装

按 [AltStore 官方 Windows 安装指南](https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows)准备软件。最小步骤如下：

1. 从 [AltStore 官网](https://altstore.io/)下载 Windows 版 AltServer，安装后运行。官网要求 Windows 10 或更新版本。
2. 安装官方指南提供的 Apple 官网版 [iTunes 64 位](https://www.apple.com/itunes/download/win64)和 [iCloud 安装程序](https://updates.cdn-apple.com/2020/windows/001-39935-20200911-1A70AA56-F448-11EA-8CC0-99D41950005E/iCloudSetup.exe)。这里采用 AltServer 指南所需的桌面版组件；Apple 新版 iCloud 的常规下载页目前默认提供 Microsoft Store 版。如果已使用 Store 版，请先阅读 [AltStore 的兼容处理说明](https://faq.altstore.io/altstore-classic/troubleshooting-guide#windows-i-need-to-use-the-windows-store-icloud)。
3. 用 USB 把 iPhone 连接到 Windows，解锁手机并选择“信任此电脑”。确认 iTunes 能看到手机；按指南登录 iTunes，启用手机的 Wi-Fi 同步。首次安装可保持 USB 连接。
4. 按住 **Shift**，点击右下角 AltServer 托盘图标，选择 **Sideload .ipa…**，选择你的手机和 `DriveFly-iOS.ipa`。此功能可以直接安装自己的 IPA，无需先安装 AltStore App。[官方功能说明](https://faq.altstore.io/release-notes/altserver)
5. 在 AltServer 自己的登录窗口使用本人的 Apple 账号，完成它要求的验证。账号及验证信息不用提供给本聊天或云 Mac。
6. 手机上打开“设置 → 通用 → VPN 与设备管理”，信任相应开发者账号。开启“设置 → 隐私与安全性 → 开发者模式”，按手机提示重启并确认。[Apple 开发者模式说明](https://developer.apple.com/news/?id=r1sz7dke)

免费 Apple 账号的开发签名配置 7 天后过期；到期前用本机 AltServer 按相同步骤重新安装。Apple 限制每台设备最多 3 个开发 App，账号同时最多 10 个 App ID。[Apple 官方限制](https://developer.apple.com/help/account/basics/about-your-developer-account)

如果 AltServer 找不到手机，先保持 USB 连接，确认信任关系及 Apple 移动设备组件已安装；如果重签失败，保存其错误码，按 [官方排错指南](https://faq.altstore.io/altstore-classic/troubleshooting-guide)处理。用户已安装旧版；本次 0.2.0 IPA 的重签和安装结果仍需验证。

### AltServer 无反馈时：改用 Sideloadly

可使用 [Sideloadly 官方 Windows 版](https://sideloadly.io/)重新签名安装，其界面提供安装日志。官方同样要求 Apple 桌面版 iTunes 和 iCloud，下载链接在官网的 Windows 下载提示中。

用 USB 连接并信任 iPhone，在 Sideloadly 选择自己的设备，拖入 `DriveFly-iOS.ipa`，输入本人 Apple ID，保持 **Apple ID Sideload** 模式并点击 **Start**。按软件提示完成密码或双重认证；安装后在 iPhone 信任账号并开启开发者模式。失败时保存安装日志中的明确错误。免费签名有效期仍为 7 天，DriveFly 的 Sideloadly 安装尚未实测。[官方 FAQ](https://sideloadly.io/faq)

## 3. 连接 Windows 游戏

1. 关闭游戏，启动已安装的 DriveFly Windows 0.4.0 Xbox 版；运行时 Windows 会识别虚拟 Xbox 360 手柄。本次手机更新无需重装电脑端。
2. 按上方说明完成 Wi-Fi、USB 个人热点或蓝牙 PAN 连接。在 DriveFly 设置中选择相应方式，输入电脑在该网络中的 IPv4 地址，点击“连接并返回”。首次连接允许本地网络访问。电脑防火墙需允许当前网络接收 UDP 7001。[Apple 本地网络权限说明](https://developer.apple.com/documentation/technotes/tn3179-understanding-local-network-privacy)
3. 横握手机，保持舒适的自然姿势，点击“校准回中”。只有收到电脑回复后，界面才显示“已连接”。
4. 点击手机顶部的“地面载具”或“飞机”按钮，检查所选模式的勾选及布局。先在 Windows 运行 `joy.cpl`，查看 Xbox 360 手柄属性的轴和按钮；连接手机后再打开 WARDOGS，关闭 HOTAS，使用普通手柄控制，L/G 在键盘键位中绑定。先低速检查每个轴的方向。

| 模式 | 左摇杆 X（LX） | 左摇杆 Y（LY） | RT | LT |
| --- | --- | --- | --- | --- |
| 地面载具 | 转向 | 中位 | 油门 | 刹车 |
| 飞机 | 横滚 | 俯仰 | 总距升高／攻击 | 总距降低 |

对抗装置使用方向键上，解锁和补给分别使用键盘 L、G。

地面踏板松手归零；飞行总距升高／降低按钮松手释放，同时按住抵消。默认 100% 比例时，飞机横滚和俯仰满量程为 ±30°，赛车转向满量程可在设置中调整。

切换模式、进入设置、切到后台或连接中断时会清空输入，恢复后重新校准。电脑连续 500 毫秒未收到有效数据也会归零；手机在前台控制时保持屏幕常亮。

云 Mac 解决的是 Apple SDK 编译；本机 Windows 负责重签并连接自己的 iPhone。云 Mac 没有 USB 连接不能保证免费 Personal Team 在 Xcode 中直接安装到远程手机。如果已有付费 Apple Developer Program，可另用注册手机 UDID、分发证书和 Ad Hoc provisioning profile 导出安装包；本工程未配置这条发行路径。[Apple Ad Hoc 要求](https://developer.apple.com/help/account/provisioning-profiles/create-an-ad-hoc-provisioning-profile/)

用户已反馈旧版地面转向相反、无法切换飞机模式；本次 0.2.0 的真机模式切换、转向修正、延迟和断线行为仍待验证。首次更新后先在 Windows Xbox 手柄属性页检查轴与按钮，再进入游戏。

此客户端按 MIT 许可开源，见 `LICENSE`；沿用 [DriveLink](https://github.com/DevBoiAgru/DriveLinkMobile) 的 Windows 通信协议。UDP 仅用于可信局域网，未加密、未认证，不要把 7001 端口开放到互联网。
